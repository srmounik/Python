#if..else if...else
salary<-80000

if(salary>50000)
{print("Good")
  }else{
  print("Ok")}

orderAmount<-45767

if(orderAmount>80000){
  discount<-900
}else if(orderAmount>60000){
  discount<-700
}else if(orderAmount>40000){
  discount<-500
}else if(orderAmount>20000){
  discount<-200
}else{
  discount<-50
}

print(discount)

#Repeat loop
repeat{
  print("Welcome")
}

cntr<-0

repeat{
  cntr<-cntr+1
  if(cntr>10)
    break;
  print(paste("Welcome",cntr))
}


cntr<-0

repeat{
  cntr<-cntr+1
  if(cntr==5) # Ignore the remaining lines for current iteration n move to the next value
    next;
  if(cntr>10) # terminate the loop
    break;
  print(paste("Welcome",cntr))
}

#While Loop

cnt<-1

while(cnt<=10){
  print(paste("Welcome",cnt))
  cnt<-cnt+1
}

prods<-c(23,56,78,34,90,10,34)


for(p in prods){
  if(p<50)
  print(paste("The price is Rs.",p))
  else
    print(paste("The price is too much...",p))
}















