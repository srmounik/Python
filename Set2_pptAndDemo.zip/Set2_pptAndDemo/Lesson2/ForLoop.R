#for Loop

v <- 14:19
for ( i in v) {
  print(i*2)
}

marks<-c(90,45,59,76,33)

for(m1 in marks){
  print(paste("The grade for ",m1))
  grade<-"F"
  if(m1>90){
    grade<-"O"
  }
  else if(m1>70)
  {
    grade<-"A"
  }
  else if(m1>50)
  {
    grade<-"B"
  }
  print(grade)
  print("------------")
}


v1 <- 1:5
for ( j in v1) {
  print(j)
}


var1<-10:17
for(temp in var1){
  print(temp)
}

weight<-c(78,34,56,90,89,100,42)
for(w1 in weight){
  print(paste("Weight is :",w1))
  if(w1<50){print("Under weight") }
  else if(w1<90){print("Normal")}
  else{print("Over weight")}
}











