#http://stackoverflow.com/questions/14113691/pictorial-chart-in-r?lq=1
#http://stackoverflow.com/questions/6797457/images-as-labels-in-a-graph?lq=1
#http://stackoverflow.com/questions/20733328/labelling-the-plots-with-images-on-graph-in-ggplot2?rq=1
#http://stackoverflow.com/questions/25014492/geom-bar-pictograms-how-to?lq=1
#http://stackoverflow.com/questions/19625328/make-the-value-of-the-fill-the-actual-fill-in-ggplot2/20196002#20196002
#http://stackoverflow.com/questions/12409960/ggplot2-annotate-outside-of-plot?lq=1
library('ggplot2')
library('scales')
library('png')
library('grid')
library('Cairo')
library('plyr')

dominoes <- data.frame(n = 1:58, height = 0.051 *1.5^(0:57)) # 2inch is 0.051 meters
base_plot <- qplot(x = n, y = height, data = dominoes, geom = "line") #+  scale_y_sqrt()
base_plot <- base_plot  + labs(x = "Sequence Number", y = "Height/Distance\n(meters)") +  theme(axis.ticks = element_blank(), panel.background = element_rect(fill = "white", colour = "white"), legend.position = "none")
base_plot <- base_plot  + theme(axis.title.y = element_text(angle = 0), axis.text = element_text(size = 18), axis.title = element_text(size = 20))
base_plot <- base_plot +  theme(plot.margin = unit(c(1,1,18,1), "lines")) + scale_y_continuous(labels = comma)
base_plot

domino_img <- readPNG("d1.png")
domino_grob <- rasterGrob(domino_img, interpolate = TRUE)

eiffel_tower_img <- readPNG("d2.png")
eiffel_tower_grob <- rasterGrob(eiffel_tower_img, interpolate = TRUE)

pisa_img <- readPNG("d3.png")
pisa_grob <- rasterGrob(pisa_img, interpolate = TRUE)

liberty_img <- readPNG("d4.png")
libery_grob <- rasterGrob(liberty_img, interpolate = TRUE)

long_neck_dino_img <- readPNG("d5.png")
long_neck_dino_grob <- rasterGrob(long_neck_dino_img, interpolate = TRUE)


#space station is 370,149.120 meters 

#this version tries to scale images by their heights
p <- base_plot + annotation_custom(eiffel_tower_grob, xmin = 20, xmax = 26, ymin = 0, ymax = 381) + annotation_custom(libery_grob, xmin = 17, xmax = 19, ymin = 0, ymax = 50) + annotation_custom(long_neck_dino_grob, xmin = 13, xmax = 17, ymin = 0, ymax = 15)

CairoPNG(filename = "domino-effect-geometric-progression.png", width = 1800, height = 600, quality = 90)
plot(p)
dev.off()



#this version just places a picture at the number
grob_placement <- data.frame(imgname = c("dinosaur-long-neck.png", "statue-of-liberty.png", "eiffel-tower.png", "space-station.png", "moon.png"),                            
                             xmins = c(13, 17, 20, 38, 53),
                             ymins = rep(-1*10^8, 5),
                             ymaxs = rep(-4.5*10^8, 5),
                             stringsAsFactors = FALSE)
grob_placement$xmaxs <- grob_placement$xmins + 4

#make a function to create the grobs and call the annotation_custom function
add_images <- function(df) {
  dlply(df, .(imgname), function(df){
    img <- readPNG(unique(df$imgname))
    grb <- rasterGrob(img, interpolate = TRUE) 
    annotation_custom(grb, xmin = df$xmins, xmax = df$xmax, ymin = df$ymins, ymax = df$ymaxs)
  })
}

img_texts <- data.frame(imgname = c("domino", "dino", "space-station", "moon"),                            
                        xs = c(1, 13, 38, 53),
                        ys = rep(-5.2*10^8, 4),
                        texts = c("1st domino is\nonly 2in",
                                  "15th domino will reach Argentinosaurus (16m).\nBy 18th domino, you will reach the statue of liberty (46m).\n23 domino will be taller than the Eiffel Tower (300m)",
                                  "40th domino will\nreach the ISS (370km)",
                                  "57th domino will\nreach the moon (370,000km)"
                        ))

add_texts <- function(df) {
  dlply(df, .(imgname), function(df){
    annotation_custom(grob = textGrob(label = df$texts, hjust = 0),
                      xmin = df$xs, xmax = df$xs, ymin = df$ys, ymax = df$ys)    
  })
}

base_plot + add_images(grob_placement) + add_texts(img_texts)

CairoPNG(filename = "domino-effect-geometric-progression-2.png", width = 1800, height = 600, quality = 90)
g <- base_plot + add_images(grob_placement) + add_texts(img_texts) + annotation_custom(domino_grob, xmin = 1, xmax = 2, ymin = -1*10^8, ymax = -5*10^8)
gt <- ggplot_gtable(ggplot_build(g))
gt$layout$clip[gt$layout$name == "panel"] <- "off"
grid.draw(gt)
dev.off()