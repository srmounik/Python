seq(10)
seq(3,6)
seq(5,15)
seq(10,200,by=15)
seq(5.8,9.2)
seq(10.25,30.02,by=1.8)
seq(10,100,length.out = 3)
seq(5,40,length.out = 7)
#seq(2:7)#2,3,4,5,6,7 => count=6 =>seq(6) ie. from 1 to 6

sequence(20)
#Invalid- sequence(5,20)

seq_len(5)

25:50

#repeat
rep(5,10)
rep(2,15)
rep("Hello",3)

marks<-c(10,20,30)
rep(marks,4)

sum(marks)
mean(marks)
min(marks)
max(marks)













