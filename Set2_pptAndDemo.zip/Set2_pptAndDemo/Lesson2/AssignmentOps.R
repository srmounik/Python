# Assignment Opeartors - =, ->, <-, ->>, <<-
#For normal variables = and <- are the same, but with DS there is a difference
age=50
age<-50
50->age

# Use <- for assignment operator
# Use = for assigning heading/names to DS 
username<-"Capgemini"

#<<- and ->> are used in functions
# They add a variable to the parent environment






x=10
print(x*5)
typeof(x)

y=40L
print(y*5)
typeof(y)

z<-10
print(z*5)
typeof(z)

# In datastructures <- assigns a value to a variable
# = is used for key value pairs
emp<-data.frame(eid=c(1,2,3),name=c("Ram","Sam","Shyam"))
print(emp)

emp<-data.frame(eid<-c(1,2,3),name<-c("Ram","Sam","Shyam"))
print(emp)

#<<- Operator, <- assigns value in the current scope
# <<- assigns value in parent scope

# -> is same as <- except for the syntax
marks<-98
98->marks

# ->> is same as <<- except for the synatx
age<<-34
34->>age
















