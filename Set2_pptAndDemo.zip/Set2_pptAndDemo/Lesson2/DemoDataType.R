# 5 types of constants

# Decimal, Integer, Complex, Character, Boolean

5+7
5%%2 #reminder of division
5%/%2 #Quotient of division

TRUE & FALSE
TRUE && FALSE

TRUE | FALSE
TRUE || FALSE

# 5 Assignment operators : =, <-, <<-,->,->>

#####Numeric Values - Double
age=10.89
mark<-56.89

typeof(age)
class(age)

typeof(mark)
class(mark)

# Any number in R is a double value
empid=101

typeof(empid)
class(empid)

# <- is the most preferred to create a variable/data structure

sales<-1678.23

# = is used in data structures for assigning Key value pair

empData<-data.frame(
   empid=101:103,
   name=c("Sam","Ruby","Edward"),
   salary=c(78788,34545,29090)
)

# <- and -> are one and the same
x<-10

typeof(x)
20->y

# <<- and ->> are used to create variables in parent enviro
# <<- and ->> example will be discussed during functions

# Integer values - L
employeeId<-102L
typeof(employeeId)
class(employeeId)

mark<-45L
typeof(mark)
class(mark)

# Complex values - i Imaginary part
error<-8+4i # Two parts Real and Imaginary
#Real =8 and Complex = 4
typeof(error)
class(error)
Re(error)
Im(error)
print(error)

rate=75i
typeof(rate)

is.complex(rate)
is.integer(rate)
is.numeric(rate)

#Logical values - TRUE, FALSE, T,F
inStock=TRUE
isAvailable=F

typeof(inStock)
typeof(isAvailable)

typeof(5>10)


#Character Variables - "" or ''

Message<-"This is too Good for Sam's book"
typeof(Message)

msg<-'Good to know'
typeof(msg)

c1<-'He said "Be Good!DO Good", I liked it'


#############as.

# Decimal to other conversion
tax<-3565.78
typeof(tax)

i1<-as.integer(tax)
typeof(i1)

c1<-as.complex(tax)
typeof(c1)

# 0 is considered as FALSE and all non zero is considered as TRUE
l1<-as.logical(tax)
typeof(l1)

cc1<-as.character(tax)
typeof(cc1)


#Integer to other conversion
tax<-7888L
typeof(tax)

i1<-as.numeric(tax)
typeof(i1)

c1<-as.complex(tax)
typeof(c1)

# 0 is considered as FALSE and all non zero is considered as TRUE
l1<-as.logical(tax)
typeof(l1)

cc1<-as.character(tax)
typeof(cc1)

x<--97
as.logical(x)


#Complex to other conversion
tax<-20+40i
typeof(tax)

i1<-as.numeric(tax)
typeof(i1)

c1<-as.integer(tax)
typeof(c1)

# 0 is considered as FALSE and all non zero is considered as TRUE
l1<-as.logical(tax)
typeof(l1)

as.logical(0+7i)
as.logical(5+0i)
as.logical(0+0i)

cc1<-as.character(tax)
typeof(cc1)


#Logical to other conversion
tax<-FALSE
typeof(tax)

i1<-as.numeric(tax)
typeof(i1)

c1<-as.integer(tax)
typeof(c1)

# 0 is considered as FALSE and all non zero is considered as TRUE
l1<-as.complex(tax)
typeof(l1)

as.logical(0+7i)
as.logical(5+0i)
as.logical(0+0i)

cc1<-as.character(tax)
typeof(cc1)


#Character to other conversion
s1<-"Welcome"
as.numeric(s1)
as.logical(s1)
as.integer(s1)
as.complex(s1)

s1<-"456"
typeof(s1)
as.numeric(s1)
as.integer(s1)
as.complex(s1)
as.logical(s1)

s1<-"FALSE"
typeof(s1)
as.numeric(s1)
as.integer(s1)
as.complex(s1)
as.logical(s1)

s1<-"1"
typeof(s1)
as.numeric(s1)
as.integer(s1)
as.complex(s1)
as.logical(s1)

#readline

fname<-readline(prompt = "Enter your first name : ")
lname<-readline(prompt = "Enter your last name : ")
age<-readline(prompt = "Enter your age : ")
age<-as.integer(age)

print(paste(fname,lname),quote = FALSE)

paste(fname,lname,age)

paste(fname,lname,age,sep="-")

print(paste(fname,lname,age,sep="*****"),quote = FALSE)

# __%s___ is __%d___ years old
sprintf("%s is \n %d years old",fname,age)

cat("Hello \n World")

cat(fname,lname,age,sep = "--")


m1<-"This is a good example of Data Visualisation"

substring(m1,12)
substring(m1,12,20)

substr(m1,12) # Invalid
substr(m1,12,20)

ip<-"The rain in Spain usually stays in plain and gives GAIN"
sub("ain","---",ip) # Replace first ain with ---
sub("AIN","---",ip) # Replace first AIN with ---
sub("AIN","---",ip,ignore.case = TRUE) # Case insensitive matter

gsub("ain","---",ip) # Replace all ain with ---
gsub("ain","---",ip,ignore.case = TRUE) # Replace all ain with ---, case insensitive manner


# 3 levels of classification
#1) Value or constant - typeof
#2) Variables or objects - class
#3) Storage allocated - mode



x <- c("a", "b", "c")
as.numeric(x)













