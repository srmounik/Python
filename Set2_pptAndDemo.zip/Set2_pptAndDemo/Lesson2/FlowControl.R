score<-54
#If else
if(score>50){
  print("Result : Pass")
}else{
  print("Result : Fail")
}

#If else if...else
if(score>=90){
  print("Grade : A")
}else if(score>=80){
  print("Grade : B")
}else if(score>=65){
  print("Grade : C")
}else if(score>=50){
  print("Grade : D")
}else{
  print("Grade : F")
}

# For Loop
marks<-c(78,34,90,23,65)

for(m1 in marks){
  print(paste("Mark processed is :",m1),quote=FALSE)
      #If else
      if(m1>50){
        print("Result : Pass")
      }else{
        print("Result : Fail")
      }
  
      #If else if...else
      if(m1>=90){
        print("Grade : A")
      }else if(m1>=80){
        print("Grade : B")
      }else if(m1>=65){
        print("Grade : C")
      }else if(m1>=50){
        print("Grade : D")
      }else{
        print("Grade : F")
      }
  
  print("--------------------------")
}

#While Statement

input<-1
sumOfNum<-0

while(input!=0){
  ip=readline("Enter a Number :(0 to Quit) :")
  input=as.numeric(ip)
  if(input==5) next;
  sumOfNum=sumOfNum+input
}

print(paste("The sum is ",sumOfNum))


input<-1
sumOfNum<-0

repeat{
  ip=readline("Enter a Number :(0 to Quit) :")
  input=as.numeric(ip)
  sumOfNum=sumOfNum+input
  if(input==0)break;
}

print(paste("The sum is ",sumOfNum))


























