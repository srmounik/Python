#Datatypes
# Every  variable belongs to a class

salary<-67567
class(salary)
is.integer(salary)
is.numeric(salary)
print(paste("Checking if ",salary,"is Numeric:",is.numeric(salary)))

age<-67L
class(age)

c1<-45+7i
class(c1)

isPass=FALSE
class(isPass)

name="Joe"
class(name)

name='Ram'
class(name)

#as.XXX 

#Decimal ie. Numeric to other types
accBalance<-56456.89
print(accBalance)
acc<-as.integer(accBalance)
print(acc)
acc1<-as.complex(accBalance)
print(acc1)

ch1<-as.character(accBalance)
print(ch1)

l1<-as.logical(accBalance)
print(l1)

# Integer to other Types

accBalance<-0L
print(accBalance)


acc<-as.numeric(accBalance)
print(acc)
acc1<-as.complex(accBalance)
print(acc1)

ch1<-as.character(accBalance)
print(ch1)

l1<-as.logical(accBalance)
print(l1)


# Complex to other Types

accBalance<-9+8i
print(accBalance)


acc<-as.numeric(accBalance)
print(acc)
acc1<-as.integer(accBalance)
print(acc1)

ch1<-as.character(accBalance)
print(ch1)

l1<-as.logical(accBalance)
print(l1)

#Character to other types

c1<-"56767"
as.integer(c1)
as.numeric(c1)
as.complex(c1)
as.logical(c1)

c1<-"Hello"
as.integer(c1)
as.numeric(c1)
as.complex(c1)
as.logical(c1)

c1<-"T"
as.integer(c1)
as.numeric(c1)
as.complex(c1)
as.logical(c1)

name="Sita"
salary=75648.676
sprintf("%s earns Rs. %5.2f", name,salary)
# __________ earns Rs _________


message<-"The rain in Spain lies in the plain"
#Substring
substr(message,5,12)
substr(message,8)
nchar(message)
substr(message,8,nchar(message))

#find and replace
message<-"The RAIN in Spain lies in the plain"
sub("ain","------",message)
gsub("ain","------",message)
sub("ain","------",message,ignore.case = TRUE)
gsub("ain","------",message,ignore.case = TRUE)

library(stringr)
str_count(message, pattern = "ain")

msg="Hello"
sprintf("%s",msg)













