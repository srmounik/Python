marks<-18

# If condition
if(marks>35){
  print("Pass")
}

# If else
if(marks>35){
  print("Pass")
}else{
  print("Fail")
}

marks<-c(56,23,78,10,72,69)
print(marks)

avgMark<-mean(marks)
print(avgMark)

myMark<-42
# Grade - >80 A,>60 B,>40 C ,< 40 D
if(myMark>80){
  grade<-"A"
  print(paste("The Grade is :",grade))
  if(myMark>avgMark){
    print("You are more than Average...")
  }else{print("You are less than Average...")}
}else if(myMark>60){
  grade<-"B"
  print(paste("The Grade is :",grade))
  if(myMark>avgMark){
    print("You are more than Average...")
  }else{print("You are less than Average...")}
}else if(myMark>40){
  grade<-"C"
  print(paste("The Grade is :",grade))
  if(myMark>avgMark){
    print("You are more than Average...")
  }else{print("You are less than Average...")}
}else{
  grade<-"D"
  print(paste("The Grade is :",grade))
  if(myMark>avgMark){
    print("You are more than Average...")
  }else{print("You are less than Average...")}
}

marks<-c(56,23,78,10,72,69)
print(marks)

# Print pass/fail for each mark

for(m1 in marks)# Each value from marks store it in m1
{
  print(paste("Processing..",m1))
  if(m1>35){
    print("Pass")
  }else{
    print("Fail")
  }
}

# Take n from user series<-1:n
# For every number print if it is Prime

# While loop
n<-readline(prompt="Enter the value for n")
n<-as.integer(n)
print(n)
cntr<-1

while(cntr<n){
  print(paste("The value is :",cntr))
  cntr<-cntr+1
}

# You have marks
marks<-c(56,23,78,10,72,69)
print(marks)

count<-length(marks)
cntr<-1

while(cntr<=count){
  data<-marks[cntr]
  cntr<-cntr+1
  if(data<30){
   # break;# Terminate the loop
    next; # Do not do the remaining for the current value and move to next value
  } else if(data>50 && data<=70)
  {
    print("Grade is B")
  }else if(data>70 && data<=90)
  {
    print("Grade is A")
  }else 
  {
    print("Grade is A+")
  }
  print(paste("-----Processed----",data))
}


repeat{
  print("Hai")
}

cntr<-1
repeat{
  print("Hai")
  cntr<-cntr+1
  if(cntr>10) break;
}




















