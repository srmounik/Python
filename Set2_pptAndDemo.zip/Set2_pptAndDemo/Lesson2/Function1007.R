
display<-function(msg){
  print("Welcome")
  print(msg)
}

display("Thats Cool")

# No param and n return type
calc<-function(){
  a<-10
  b<-20
  c<-a+b
  print(paste("The Result is",c))
}

calc()

typeof(calc)
class(calc)
mode(calc)


# Many params
doMath<-function(a,b,c,d){
  t1<-a*c
  t2<-b+d
  res<-t1+t2
  print(paste("The Result is",res))
}

#Positional notation
doMath(2,3,5,9) # a=2, b=3,c=5,d=9

#named notation
doMath(c=10,b=8,a=3,d=5)

#Mixed notation
doMath(b=10,d=8,3,7) # a=3 , b= 10, c=7 , d=8


# Default params
doMath<-function(a,b=7,c,d=2){
  t1<-a*c
  t2<-b+d
  res<-t1+t2
  print(paste("The Result is",res))
}

doMath(10,5,2,3) # a=10,b=5,c=2,d=3
doMath(10,5,2)# a=10,b=5,c=2,d=2
doMath(10,5) # a=10,b=5, c= ?????????, d=2
doMath(a=10,c=5)
doMath(5, ,2)
doMath(2,3,4,5,6)

#R functions are Lazzzzzzzzzzzy
disp<-function(a,b){
  print("Welcome...")
  print(paste("A =",a))
  print("Thank U....")
  print(b)
}

disp(7)

# All R functions by default return the value of the last statement executed

calc<-function(){
  a<-10
  b<-20
  c<-a+b
  x<-100
}

ans<-calc()
print(ans)



marks<-readline(prompt = "Enter the mark : ")
calcGrade<-function(){
  if(marks<50)
    grade<-"F"
  else if(marks<=60)
    grade<-"D"
  else if(marks<=70)
    grade<-"C"
  else if(marks<=80)
    grade<-"B"
  else
    grade<-"A"
  
  return(grade)
}

g1<-calcGrade()
print(g1)

# Global vs Function Enviro

f1<-function(){
  x<-10 # Local variable to the functiobn
}


# Global vs Function Enviro

f2<-function(){
  a<-10 # Local variable to the function
  b<<-20 # Global variable ie. created in the parent environment
  30->>c1
}



fn1<-function(){
  a<-10 #fn1 - a=10
  b<-20 #fn1 - b=20
  print("---In outer function---")
  print(paste("a=",a))
  print(paste("b=",b))
  
  #Inner nested function
  fn2<-function(){
    a<-30 # Local variable to function fn2 - a =30
    # fn2 changed fn1's b=40
    b<<-40 # In the parent function fn1, there is a variable b, assign the value 40
    print("---In Inner function---")
    print(paste("a=",a))
    print(paste("b=",b))
  }
  
  fn2()
  print("---In outer function---")
  print(paste("a=",a))
  print(paste("b=",b))

}

f1<-function(){
  a<<-10; #parent environment
  a<-20; #Local within the function
  print(a);
  #e<-parent.env(environment())
  #x<-get('a',envir = e);
  print(get('a',envir = parent.env(environment())))
}

# Recursive functions

factorl<-function(x){
  if(x==0) return(1)
  else return(x*factorl(x-1))
}


#Switch

switch( 2,print("Hai"),print("Welcome"),print("OOPS"),print("Thank U"))

switch( 3,print("Hai"),print("Welcome"),print("OOPS"),print("Thank U"))












