myFunction<-function(x)
{
 print(paste("Input is ",x))
 y<-x*2
 return(y)
}
temp12<-0

m1<-function(m)
{
  score<-100
  print(paste("Outer",score))
  print(paste("Outer",temp12))
  m2<-function(){
    score<-200
    temp12<-1000
    print(paste("Inner",score))
    print(paste("Inner",temp12))
  }
  m2()
  print(paste("Outer",score))
  print(paste("Outer",temp12))
}