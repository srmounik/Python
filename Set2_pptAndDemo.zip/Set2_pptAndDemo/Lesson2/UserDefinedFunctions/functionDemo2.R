MathOfValues<-function(a,b,c){
  x<-a+b*c
  print(paste("Result is",x))
}

MathOfValues(2,3,7)# Positional notation
MathOfValues(c=10,a=4,b=2) # Named notation
MathOfValues(b=6,3,5)# Mixed notation

# Default values

Calculate<-function(a,b=10,c=2,d){
  x<-a*b
  y<-c-d
  result<-x+y
  print(paste("Result is",result))
}

Calculate(4,3,10,5)
Calculate(a=4,d=2)
Calculate(3,5,7)
Calculate(3,,5,7)
Calculate(2,,,4)

# Parameters to functions are Lazy bound 
f1<-function(a,b)
{
  res<-a^2
  print(paste("Result is",res))
  print("Thank U")
  res2<-b^2
  print(paste("Result is",res2))
}
f1(7)

ans<-f1(5,3)


findGrade<-function(){
  if(salary<=25000)
    grade<-"A"
  else if(salary<=35000)
    grade<-"B"
  else if(salary<=45000)
    grade<-"C"
  else grade<-"D"
  return(grade)
}

salary<-readline(prompt="Enter ur salary : ")
g<-findGrade()
print(paste("The Grade is : ",g))

switch(3,67,89,45,72,10,59)

marks<-c(89,45,24,90,12,78,100,56)
ch<-readline(prompt="Enter ur choice :1->Sum, 2->Mean, 3->Min, 4->Max : ")
ch<-as.integer(ch)
switch(ch,sum(marks),mean(marks),min(marks),max(marks))













