print_factors <- function(x) {
  print(paste("The factors of",x,"are:"))
  for(i in 1:x) {
    if((x %% i) == 0) {
      print(i)
    }
  }
}


print("Printing factors of 30")
print_factors(30)
print("Printing factors of 12")
print_factors(12)