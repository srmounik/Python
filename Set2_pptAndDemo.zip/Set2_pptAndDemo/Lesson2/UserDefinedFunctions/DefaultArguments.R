namedFn<-function(x,y)
{
  print(paste("X=",x))
  print(paste("Y=",y))
  print(paste("X power Y",x^y))
}

namedFn(6,2)
namedFn(y=6,x=2)
namedFn(8,x=2)

# Create a function with arguments.
new.function <- function(a = 3, b=10,c) {
  result <- a * b*c
  print(result)
}

# Call the function without giving any argument.
new.function()

# Call the function with giving new values of the argument.
new.function(9,5)

# Call the function with giving new values of the argument.
new.function(,,4)#new.function(,,c)

new.function(c=7)