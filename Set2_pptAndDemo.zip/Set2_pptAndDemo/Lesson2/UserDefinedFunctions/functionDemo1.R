# Without parameters
sumofNum<-function(){
  num1<-90 # Functions scope
  num2<-40 # Functions scope
  print(num1+num2)
}

sumNums<-function(){
  n1<<-80 # Parent's scope ie. Global Environment
  n2<<-45 # Parent's scope ie. Global Environment
  print(n1+n2)
}

m1<-function()
{
  x<-10
  y<-20 
  print("In Outer.....")
  print(paste("x=",x))
  print(paste("y=",y))
  m2<-function()
  {
    x<-30
    y<<-40 # Parent scope ie. function m1()
    print("In Inner.....")
    print(paste("x=",x))
    print(paste("y=",y))
  }
  m2()
  print("In Outer.....")
  print(paste("x=",x))
  print(paste("y=",y))
}

m1()




m1<-function()
{
  x<-10
  y<-20 
  print(paste("x=",x))
  print(paste("y=",y))
  m2<-function()
  {
    x<-30
    y<<-40 
    print(paste("x=",x))
    print(paste("y=",y))
  }
  m2()
  print(paste("x=",x))
  print(paste("y=",y))
}

m1()














