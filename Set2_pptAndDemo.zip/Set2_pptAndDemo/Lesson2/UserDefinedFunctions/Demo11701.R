#Function without parameters
display<-function(){
print("Welcome to R function")
}

#Function with parameters
sumOfNums<-function(x,y,z,p,q,r){
  sumRes<-0
  sumRes<-x+y+z+p+q+r
  print(paste("The sum of the numbers is :",sumRes))
}

#Function with parameters - Named vs Positional
MathOfNums<-function(x,y,z){
  res1<-x^y
  res2<-z-x
  print(paste("x=",x,"y=",y,"z=",z))
  print(paste("Result 1=",res1))
  print(paste("Result 1=",res2))
}

MathOfNums(y=9,z=21,x=2)


outer<-function(){
  # Create a variable in the function with name var1
  # This variable is visible only inside the function
  var1<-10 
  
  # In Global environment there is a variable var2, change its value as 20
  var2<<-50
}


f1<-function(){
  x<-10
  print(paste("Value of x =",x))
  f2<<-function(){
    print("-------Inner--------")
    y<-23
    print(paste("Value of y =",y))
    x<<-67
    print("-------Inner Ends--------")
    var2<<-90
  }
  f2()
  print(paste("Value of x =",x))
}




fun1<-function()
{
  x<-10#Create a variable x in fun1
  print(paste("Value of x =",x))
  fun2<-function(){
    x<-20#Create a variable x in fun2
    print(paste("Value of x =",x))
  }
  fun2()
  fun3<-function(){
    x<<-40 # Access the variable x in parent function
  }
  fun3()
  print(paste("Value of x =",x))
}



























