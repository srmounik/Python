#Multiple return

multi_return <- function() {
  my_list <- list("color" = "red", "size" = 20, "shape" = "round")
}

a <- multi_return()

print(a)


a$color

a$size

a$shape