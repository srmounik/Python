#Infix Opertaor

`+`(5,3) # 5+3 or `+`(5,3)
`-`(5,3)

`%divisible%` <- function(x,y)
{
  print(paste(x,y))
  if (x%%y ==0) return (TRUE)
  else          return (FALSE)
}

10 %divisible% 3
10 %divisible% 2
`%divisible%`(10,5,3)

n1<-c(1,2,3,4)
n2<-c(5,6,7,8)
n3<-n1%x%n2
print(n3)


