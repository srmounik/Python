#Conditional statement
x <- 30L
if(is.integer(x)) {
  print("X is an Integer")
}

#Check the age of an Employee
age<-13
if(age>18){
  print("You are authorised to work",quote = FALSE)
}else{
  print("You are not authorised to work",quote = FALSE)
}

#if...else
x <- c("what","is","Truth")

if("Truth" %in% x) {
  print("Truth is found")
} else {
  print("Truth is not found")
}

age<-25
AGE<-16
if(age<18){
  print(" You cannot Vote !!")
}else {
  print(" Please cast your vote")
}

#if....else if

x <- c("what","is","truth")

if("Truth" %in% x) {
  print("Truth is found the first time")
} else if ("truth" %in% x) {
  print("truth is found the second time")
} else {
  print("No truth found")
}


balance<-17000L
if(balance<=10000)
{
  print("Sorry! Low balance!")
}else
{
  print("Sufficeint balance!")
}


hbA1c<-readline(prompt="Enter your hbA1c value")
hbA1c<-as.integer(hbA1c)
if(hbA1c<6){
  print("Normal")
}else if(hbA1c<=8)
{
  print("In Good control")
}else if(hbA1c<=10)
{
  print("Needs medication")
}else{
  print("Consult a doctor")
}













age<-25

if(age<18){
  print(" You cannot Vote !!")
} else if (age<30) {
  print(" Welcome to Youth forum")
}else {
  print(" Please cast your vote")
}


#switch

x <- switch(
  8,
  "first",
  "second",
  "third",
  "fourth"
)
print(x)


value1<-switch(4,"A","Hello","World","Scooby","Mickey","Donald")
print(value1)


marks<-c(78,56,45,89,90,23,45)
print(" 1:Add, 2:Average, 3:Minimum, 4:Maximum")

ch<-readline(prompt="Enter your choice :")

ch<-as.integer(ch)

result<-switch(ch,sum(marks),mean(marks),min(marks),max(marks))
print(paste("Result is",result),quote = FALSE)










