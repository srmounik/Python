marks<-c(78,34,67,29,94,23,12,55,18,84)
marks

marks[4]

marks[0]

# Access the 2nd,5th and 9th element
marks[c(2,5,9)]

indxs<-c(1,6,8)
marks[indxs]

#Display all the values except the 4th value
marks[-4]

marks[c(-1,-4,-7,-8)]

marks[c(1,-4)]

marks[c(2.65,4.12)]

#Logical index
marks[c(T,F,T,F,T,F,F,F,F,F)]

# Vector has 10 elements, logical index has 2 values.It wull repeat the 2 values
marks[c(F,T)]

marks
marks[c(TRUE,TRUE,FALSE)]

names<-c("Ram","Tim","Shyam","Arun","Varun","Tarun","Sita")

names[2]

names[c(3,5,7)]

names[c(T,F,T,T,T,F,F)]

salary<-c(90565,34565,78797,23898,34546)
salary

names(salary)<-c("Hira","Twinkle","Suraj","Adhi","Kavin")
salary

temp<-salary["Hira"]
salary["Hira"]<-salary["Twinkle"]
salary["Twinkle"]<-temp
salary

salary["Suraj"]

salary[c("Adhi","Hira")]

salary[c(1,3,5)]


scores<-c("Dhoni"=98,"Kholi"=105,"Chahal"=78,"Ashwin"=56)
scores


marks<-c(78,34,67,29,94,23,12,55,18,84)
marks

marks[5]<-98

marks[marks<35]<-40

marks<-marks[1:5]

marks<-c(78,34,67,29,94,23,12,55,18,84)
marks
marks[as.logical("Hai")]

marks[as.logical(c(0,1,1,1,0,0,0,0,1,0))]

























