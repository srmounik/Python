v1<-c(8,4,5,6,7,9)
typeof(v1)
names<-c("Ram","Suraj","Vinay","Sam","Sita")
typeof(names)
hasRegistered<-c(TRUE,FALSE,TRUE,FALSE)
typeof(hasRegistered)

ids<-45:61
ids

marks<-seq(30,60,by=4)
marks

random<-rep(6,8)
random

v2<-c(1:5,seq(20,24),rep(6,3),51,80)
v2
length(v2)

#Logical ->Number, Anything -> Character
v3<-c(TRUE,FALSE,67,34,60,12)
print(v3)
print(typeof(v3))

v4<-c(TRUE,FALSE,TRUE,FALSE,67,34,60,12,"CG","LnD")
print(v4)
print(typeof(v4))

v5<-c(TRUE,FALSE,"CG","LnD")
print(v5)
print(typeof(v5))


v6<-c(8i,9+2i,67,34,60,12)
print(v6)
print(typeof(v6))

v7<-c(8i,9+2i,TRUE,FALSE)
print(v7)
print(typeof(v7))










