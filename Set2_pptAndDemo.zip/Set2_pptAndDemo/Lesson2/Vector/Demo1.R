names<-c("Ram","Sita","Arun","Arjun")
names<-c("Ram","Sita","Arun","Arjun",1,45,23,TRUE,FALSE,TRUE)
marks<-c(10,34,56,TRUE,FALSE,TRUE,FALSE)

sales<-c(1000,2000,3000)
months <-1:12

values<-seq(1, 9, by = 2)
values

# values<-c(1,3,5,7,9)
#rep is used to repeat
p_vector <- rep(values,2)
p_vector

q_vector<-c(1,3,1:5,seq(1,4,by=2),rep(3,8))
q_vector

marks <- c(10,20,30,40,50,"car",'abc',"1.2l",TRUE,FALSE) 
marks

# Start from 10 end with 100, increment by 2.75
v3<-seq(10,100,by=2.75)
v3

# Start with 10, end with 100, and print only 7 numbers

v4<-seq(10,100,length.out = 8)
v4

y <-3.8:11.4













