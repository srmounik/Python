# No param, no return type

evaluate<-function(){
  n1<-10 # declared in function scope
  n2<-20 # declared in function scope
  ans<-n1*2+n2
  print(paste("Result is :",ans))
}

compute<-function(){
  n1<-10 # declared in function scope
  n2<-20 # declared in function scope
  ans<-n1*2+n2+n3 # n3 is a global variable
  n3<<-42 # 42->>n3 # <<-,->> means change the value of the variable in parent scope
  print(paste("Result is :",ans))
}

# Nested function

f1<-function(){
  n1<-10 # declared in function scope
  n2<-20 # declared in function scope
  print("-----Outer function------")
  print(paste("n1= ",n1))
  print(paste("n2= ",n2))
  f2<-function(){
    n1<<-40 # change n1 which is in parent - f1()
    n2<-30 # declared in function scope
    print("-----Inner function------")
    print(paste("n1= ",n1))
    print(paste("n2= ",n2))
  }# f2 ends
  f2()
  print("-----Outer function------")
  print(paste("n1= ",n1))
  print(paste("n2= ",n2))
}

# Functions with params

calculate<-function(a,b,c){
  ans<-a*b+c
  print(paste("Result is :",ans))
  ans1<-factOfNum(7)
  print(paste("Factorial of 7 is :",ans1))
}

#Positional notation
calculate(10,2,5)

#Named notation
calculate(c=89,a=5,b=3)

# Mixed notation b=10, a=3, c=6 (3*10)+6
calculate(b=10,3,6)

# Default values to parameters

calc<-function(a,b=6,c){
  ans<-a*b+c
  print(paste("Result is :",ans))
}
calc(2,5,7)
calc(5,4)#a=5,b=4, c is not assigned a value
calc(5,,4)
calc(a=5,c=4)

# Lazy function - it searches for a parameter only when it needs it
getOp<-function(a,b){
  res<-a^2
  print("Processing a^2")
  print(res)
}

getOp(4)

# Return value
# Every R function by default returns the result of the last statement

getResult<-function(a,b,c,d){
  ans1<-a*b
  ans2<-c^2
  ans3<-d+4
  ans1
}

res<-getResult(5,2,4,10)
print(res)


getResult<-function(a,b,c,d){
  ans1<-a*b
  ans2<-c^2
  ans3<-d+4
  return("Thank U")
}

res<-getResult(5,2,4,10)
print(res)

#Recursive function
factOfNum<-function(n){
  if(n==0) return(1)
  else return(n*factOfNum(n-1))
}


f1<-function(a,b)
{
  res<-a*5
  print(res)
}

f1(7)

switch(3,
       10,20,30,40,50
)

marks<-c(89,34,56,10,90,23,66,92)
ch<-readline(
prompt="Enter ur choice 1-> Sum, 2-> Average, 3-> Min, 4-> Max : ")
ch<-as.integer(ch)
print(paste("Choice is :",ch))

switch(ch,sum(marks),mean(marks),min(marks),max(marks))





