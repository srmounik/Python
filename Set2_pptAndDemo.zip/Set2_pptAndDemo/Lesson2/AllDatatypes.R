#Numeric
x = 10.5
class(x)
typeof(x)
y=11
class(y)
typeof(y)
#The fact that y is not an integer can be confirmed with the is.integer function.
is.integer(y)

#Integer
m=as.integer(x);# x=10.5
class(m)
typeof(m)
print(m)

n=as.integer(6.7);
typeof(n)
print(n)

n1=8L
typeof(n1)
class(n1)
print(n1)

o=as.integer("8.9");
print(o)
is.integer(o)

#Complex
#A complex value in R is defined via the pure imaginary value i.
z = 34 + 2i     
class(z)
Re(z)
Im(z)

v1<-87i
Re(v1)
Im(v1)



#Logical
limit=10000
withdraw=20000
isAllowed=withdraw<limit
print(isAllowed)
class(isAllowed)

u=TRUE;
v=FALSE;
print(u&v)
print(u|v)
print(!v)

#Character

x = as.character(3.14) 
print(x)
class(x)
fname = "Joe"; lname ="Smith" 
paste(fname, lname) 


sprintf("%s has %d dollars", "Sam", 100) 
sprintf("%s has %d dollars", fname, limit)

stmt="%s has %d dollars"

sprintf(stmt,lname,withdraw)

substr("Mary had a little lamb.", start=3, stop=12) 
substr("Mary had a little lamb.",start=5, stop=45) 

substring("Mary had a little lamb.",3,12)

substr("Mary had a little lamb.", start=3) 
substring("Mary had a little lamb.",3)

length("Mary had a little lamb.")
count("Mary had a little lamb.")
charcount("Mary had a little lamb.")
nchar("Mary had a little lamb.")

length("Hello")

length(c("Hello","Welcome"))

length(3)
length(1:10)

sub("LITTLE", "big", "Mary has a Little lamb.",ignore.case = TRUE) 

sub("AIN","---","The rain in Spain is mostly in the plain",ignore.case = TRUE)

gsub("AIN","---","The rain in Spain is mostly in the plain")

gsub("AIN","---","The rain in Spain is mostly in the plain",ignore.case = TRUE)
gsub("AIN","---","The rain in Spain is mostly in the plain",ignore.case = TRUE)

gsub(x="The 3 Things 4 U",pattern = "[A-Z][a-z]{2}",replacement = "###", perl =FALSE)


msg="Go Go Go and you go get it"
gsub("Go","Do",msg)
sub("go","will",msg)
# as. functions
# converting decimals
x=23
y=0
as.integer(x)
as.integer(y)
as.logical(x);as.logical(y)
as.logical(-34)
as.character(x);as.character(y)
as.complex(x);as.complex(y)

# Converting Logical
x1=TRUE
y1=FALSE
as.integer(x1)
as.integer(y1)
as.character(x1);as.character(y1)
as.complex(x1);as.complex(y1)

# Converting Character
x="1"
y="a"
z="TRUE"
m="hello"
n="6.7"
o="4+5i"

as.integer(x)
as.integer(y)
as.integer(z)
as.integer(m)
as.integer(n)
as.integer(o)

as.logical(x);as.logical(y);as.logical(z)
as.logical(m);as.logical(n);as.logical(o)

x <- c("a", "b", "c")
as.numeric(x)











