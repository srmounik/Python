#Sequence
1:10
seq(23) # 1 to 23
seq(30,60)
seq(40,100,by = 3) # Skip count is 3

seq(1,30,8)
seq(30,200)

seq(5,200,length.out = 12) # Gimme 12 numbers from 5 to 200

seq_len(5)
seq_len(6,20) #Error

sequence(12)
sequence(30)

# Repeat 

rep(5,20) # Repeat 5, 20 times

rep("Welcome",8)

rep(c("Yes","No"),4)

rep(c("Yes","No"),c(5,3)) # "Yes" - 5 times and "No" - 3 times

rep(c(101,240,89),c(2,5,100)) # Input - 101,240,89 , Repeat - 2,5,100
# Print 101 - 2 times, 240- 5 times, 89 - 100 times

regNo<-NA
is.na(regNo)

sample(1:10,5,replace = TRUE)

rep(c("Y","N","Y","N","Y","N"),sample(1:10,6))

sqrt(-17)






