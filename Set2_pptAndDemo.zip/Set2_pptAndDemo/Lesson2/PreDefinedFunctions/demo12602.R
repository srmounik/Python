# sequence generating functions
4:20
seq(4,20)
seq(4,20,by=3)
seq(4,20,by=3.5)
seq(20,4,by=-2)
seq(100,150,length.out = 5)

seq(1,10,by=3)#by=3, 1,4,7,10 -> no of values=4
seq(1,10,length.out = 5) # No of values =5 (10-1)/5=9/4 1,3.25,5.50,7.75,10

seq_len(5)
seq_len(100)
seq_len(89,120)

sequence(20)

vals<-seq(1,40,by=2)
vals[5:10]

rep(7,3)

rep("Hello",5)

1:4

rep(1:4,3)

rep(1:4,5:8)#rep((1,2,3,4),(5,6,7,8))

rep(1:2,c(3,10))

rep(1:5,3:4)# Input = 1,2,3,4,5 rep=3,4

sqrt(-17)
4/0
-20/0

marks<-c(35,28,NA,10,90,76,NA,59,NA)
order(marks,na.last = FALSE)
sort(marks,na.last = TRUE)
sort(marks,decreasing = TRUE)
marks[order(marks)]

f1<-function(){}

f1()






