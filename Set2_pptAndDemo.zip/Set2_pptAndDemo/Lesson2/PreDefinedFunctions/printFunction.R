# to find all the variables declared till now
print(ls())

# List the variables starting with the pattern "var".
print(ls(pattern = "f")) 

# List the variables starting with the pattern "var".
print(ls(pattern = "1"))  

print(ls(pattern = "e")) 

#The variables starting with dot(.) are hidden, they can be listed using "all.names = TRUE" argument to ls() function.
print(ls(all.name = TRUE))

#Delete a variable using rm
rm(ch)

# Delete all variables using rm and ls
rm(list = ls())