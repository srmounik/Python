sequence(10)

#Invalid - sequence(56,69)

seq(56,69)

seq(10)

seq(5,90,by = 4)

seq(5,90,length.out = 8)
seq(0,20,length.out=5)

seq(1,20,by=2)

seq(100,50,by=-6)

67:89

sum(1:10)
sum(seq(5,90,by = 4))
mean(seq(5,90,by = 4))

# Create a sequence of numbers from 32 to 44.
print(seq(32,44))

# Find mean of numbers from 25 to 82.
print(mean(25:82))

# Find sum of numbers frm 41 to 68.
print(sum(41:68))
print(sum(1:5))

# Repeat function - Repeat arg1, arg2 times rep(7,3)- repeat 7, 3 times
x<-0:6

rep(11,30)# Repeat 11, 30 times

rep(2:6,5)

rep(1:4,6:9)# (1,2,3,4)(6,7,8,9)

f1<-function(){
  return("Thank You")
}

msg=f1()
print(msg)
rep(f1(),3)