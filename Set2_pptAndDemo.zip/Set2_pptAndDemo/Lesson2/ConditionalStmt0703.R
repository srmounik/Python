# Flow control
# Conditional statements
#if
age<-34

if(age<18){
  print("You are not eligible to work")
}

#if...else
balance<-8000
if(balance<=10000){
  print("Please maintian Minimum Balance!!!")
}else{
  print("Perfect Balance!!!") 
}

if(balance<=10000){
  print("Please maintian Minimum Balance!!!")
  }else{
  print("Perfect Balance!!!") }



#if...else if
marks<-readline(prompt="Enter your mark : ")
if(marks<35)
{
  grade<-"F"
  print(paste("Grade for the mark",marks,"is :",grade))
}else if(marks<=50){
  grade<-"C"
  print(paste("Grade for the mark",marks,"is :",grade))
}else if(marks<=70){
  grade<-"B"
  print(paste("Grade for the mark",marks,"is :",grade))
}else if(marks<=80){
  grade<-"A"
  print(paste("Grade for the mark",marks,"is :",grade))
}else{
  grade<-"A+"
  print(paste("Grade for the mark",marks,"is :",grade))
}

#Iteration

n1<-c(1,2,3,4,5)
#For each iterator
for(temp in n1){
  print(temp)
  print(paste("temp*temp=",temp*temp))
}


names<-c("Mark","Gru","Michael","Tom")
for(n1 in names){
  print(paste("The name is ",n1))
  print(paste("The number of characters in",n1,"is",length(n1)))
}



# find the grade of 5 students
scores<-c(10,98,76,56,55)

for(marks in scores)
{
  print(paste("----Processing",marks,"------"))
    if(marks<35)
    {
      grade<-"F"
      print(paste("Grade for the mark",marks,"is :",grade))
    }else if(marks<=50){
      grade<-"C"
      print(paste("Grade for the mark",marks,"is :",grade))
    }else if(marks<=70){
      grade<-"B"
      print(paste("Grade for the mark",marks,"is :",grade))
    }else if(marks<=80){
      grade<-"A"
      print(paste("Grade for the mark",marks,"is :",grade))
    }else{
      grade<-"A+"
      print(paste("Grade for the mark",marks,"is :",grade))
    }
}



cntr<-1
while(cntr<10)
{
  print(paste("The value is",cntr))
  cntr<-cntr+1
}



scores<-c(10,98,76,56,55)

#Find the sum of marks
len<-length(scores)
cntr<-1

while(cntr<=len){
  if(cntr==1)sum1<-0
  sum1<-sum1+scores[cntr]
  cntr<-cntr+1
}

print(paste("The sum is",sum1))


#break - come out of the loop and stop the loop

cntr<-1
while(cntr<10)
{
  print(paste("The value is",cntr))
  cntr<-cntr+1
  if(cntr==5)
    break;
  print("-----------------------------")
}

#next - will stop the loop for the current value and go to the next value

cntr<-1
while(cntr<10)
{
  print(paste("The value is",cntr))
  cntr<-cntr+1
  if(cntr==5)
    next;
  print("-----------------------------")
}




grades<-c("A","B","C","D","A","D","E","D","C")
#Dont print rating for grade D and E

len<-length(grades)
cntr<-1

while(cntr<=len){
  temp<-grades[cntr]
  cntr<-cntr+1
  if(temp=="D"||temp=="E") next;
  print("--------- Rating ------------")
  print(paste("Grade :",temp))
  print("Rating : 2")
}


#print rating until you find a grade D or E

grades<-c("A","B","C","D","A","D","E","D","C")
len<-length(grades)
cntr<-1

while(cntr<=len){
  temp<-grades[cntr]
  cntr<-cntr+1
  if(temp=="D"||temp=="E") break;
  print("--------- Rating ------------")
  print(paste("Grade :",temp))
  print("Rating : 2")
}


repeat{
  print("I love R")
}

cntr<-1
repeat{
  print("I love R")
  cntr<-cntr+1
  if(cntr>10) break;
}











