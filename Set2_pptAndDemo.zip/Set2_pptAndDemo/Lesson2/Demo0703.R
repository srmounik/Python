user.Name="cg"
user_name="cg"
.Element5="TV"
#.5thElement="TV"
#5thElement="TV"
print(.Element5)

#Constants
#Numeric constant- double,integer,complex
typeof(67)
typeof(45.23)
#Integer
typeof(67L)
typeof(as.integer(45.23))

x=as.integer(45.23)
print(x)

#Complex
v1=6+9i
typeof(v1)

typeof(9+0i)

print(x)

c1=as.complex(x)
print(c1)

#Character - "" or ''
age="25"
typeof(age)

message="Leave the room by 6pm"
typeof(message)

m1="This is Shyam's pen"
typeof(m1)

msg='Netagi said "Do or Die"'
typeof(msg)
print(msg)

name=readline(prompt="Enter your name : ")
age=readline(prompt="Enter your age : ")
print(paste("Name:",name,"     Age:",age))

x=10
y<-10
10->z
m1<<-10
10->>m2

temp<-c(10,12,34,45) #<- creates a variable temp 
temp<-c("Jan"=10,"Feb"=12,"Mar"=34,"Apr"=45)# = is used to give names
names(temp)

#<<- or ->> do,
#<<- or ->> declare variables in the current scope
#<- or -> declare variables in the parent scope
# f1(), in f1() temp<<-10, variable temp is declared in f1() scope
# f1(), in f1() age<-25, variable age is declared in parent scope-global
# nested f1(){ f2()}, for f2(), f1() is parent

n1<-90
n2<-23
n3<-2

n1+n2
n1-n2
n1*n2
n1/n2
n1^n3 # 90 to the power to 2

n1%%n2 # Reminder of division

n1%/%n2 # Divide n1/n2 and truncate the decimate and give result as integer


interest=905.99
as.integer(interest)

print(interest<1000)
print(interest>=1000)

print(0&3)

print(0|3)

# & vs &&, | vs ||
m1<-c(0,3,0,4)
m2<-c(1,2,0,5)
m1&m2 # 0&1, 3&2, 0&0, 4&5
m1|m2 #0|1, 3|2, 0|0, 4|5

m1&&m2 #0&&1
m1||m2 #0||1


var1<-NULL
typeof(var1)
class(var1)

price<-4453.56
class(price)

age<-35L
class(age)

form1<-8+9i
class(form1)

rollNo<-"89"
class(rollNo)

value="TRUE"
class(value)

name<-'Henry Smith'
class(name)
print(name)

# TRUE,FALSE or T and F or 0=FALSE, non zero means TRUE
isAvaialable<-TRUE
class(isAvaialable)

inStock<-F
class(inStock)


#Numeric datatypes conversion

n1<-89.345
class(n1)
print(n1)

n2<-as.integer(n1) # truncate the decimal part
class(n2)
print(n2)

n3<-as.complex(n1) # 0i will be added
class(n3)
print(n3)

n4<-as.character(n1) # 0i will be added
class(n4)
print(n4)

n5<-as.logical(n1) # 0i will be added
class(n5)
print(n5)

h1<-6237844238959405934096506L
print(h1)


#Integer datatypes conversion

n1<-45L
class(n1)
print(n1)

n2<-as.numeric(n1) # include the decimal part
class(n2)
print(n2)

n3<-as.complex(n1) # 0i will be added
class(n3)
print(n3)

n4<-as.character(n1) # 0i will be added
class(n4)
print(n4)

n5<-as.logical(n1) # 0i will be added
class(n5)
print(n5)

n1=0
n5<-as.logical(n1) # 0i will be added
class(n5)
print(n5)


#Complex datatypes conversion

n1<-45.23+87i
class(n1)
print(n1)

n2<-as.numeric(n1) # include the decimal part
class(n2)
print(n2)

n3<-as.integer(n1) 
print(n3)

n4<-as.character(n1) # 0i will be added
class(n4)
print(n4)

n5<-as.logical(n1) # 0i will be added
class(n5)
print(n5)

n1=9+0i
n5<-as.logical(n1) # 0i will be added
class(n5)
print(n5)

n1=0+9i
n5<-as.logical(n1) # 0i will be added
class(n5)
print(n5)

n1=0+0i
n5<-as.logical(n1) # 0i will be added
class(n5)
print(n5)

#Character conversion
c1<-"5.67" #numeric,integer,complex
c2<-"Hello"
c3<-"TRUE" #logical
c4<-"F"    #logical
c5<-"67+9i" #complex

as.numeric(c1)
as.complex(c1)
as.numeric(c2)
as.numeric(c3)
as.numeric(c4)
as.complex(c5)

as.logical(c1)
as.logical(c2)
as.logical(c3)
as.logical(c4)
as.logical(c5)

#Conversion of logical types
l1=TRUE
l2=T
l3=FALSE
l4=F
as.numeric(l1)
as.integer(l2)
as.complex(l2)
as.numeric(l4)

as.character(l1)
as.character(l2)


n1=1
as.logical(n1)







