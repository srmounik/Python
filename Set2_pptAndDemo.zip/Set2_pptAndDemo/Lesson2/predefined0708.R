1:10

seq(5)
seq(from = 2,to = 50)
seq(from = 2,to = 50,by=10)
seq(from = 2,to = 50,length.out = 8)

seq_len(20)

sequence(9)

rep("Hello",3)
rep(5,18)

rep(c(3,4,5,6),10)

rep(c("Yes","No"),5)

sum(1:10)
sum(c(4,7,10,2))
min(c(4,7,10,2))
max(c(4,7,10,2))
range(c(4,7,10,2))

switch(2,
       print("Hai"),
       print("OOPS"),
       print("Welcome"),
       print("Thank U"))

switch(0,
       print("Hai"),
       print("OOPS"),
       print("Welcome"),
       print("Thank U"))

f<-function(){}
f()

