#Assignment Operators
# Create variables in the current package
x=5
y<-5

#Create variables in Global environment
z<<-5

library(base)
company<-"Capgemini"

"CG"->comp

#Arithmetic Operations
x=13
y=4

print(x+y)
print(y-x)
print(x^y)

print(x/y)
print(x%%y)
#x=13 and y=4
print(x%/%y)

print(9.76/3.9)
print(8.76/2.4) # 3.65
print(8.76%/%2.4) # 3.65 -> truncated to integer =3
print(7.96%/%2.4)

print(x<y)
print(x>y)

message1="Thanks"
message2="thanks"
message3="Thanks"

print(message1==message2)
print(message1==message3)


#Logical Operators
appeared<-c(TRUE,FALSE,FALSE,TRUE)
cleared<-c(TRUE,TRUE,FALSE,FALSE)

print(appeared & cleared)

print(appeared && cleared)

print(appeared | cleared)

print(appeared || cleared)


class(print)


















