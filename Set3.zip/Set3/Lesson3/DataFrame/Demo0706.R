#Dataframe is a 2Dimensional DS - But every column has a different type
sink("NewFile.txt",append = TRUE)
product<-data.frame(
       'pid'=101:106,
       "pname"=c("LCD","Pen","Garments","Furniture","Tablets","Laptop"),
       "price"=c(54647,NA,6767,NA,23909,56565),
       "inStock"=c(T,F,T,T,T,T),
       stringsAsFactors = FALSE
)
print(product)

product[product$inStock==TRUE,]

print("**************************")
print("Sum of Product price")

print(sum(product$price,na.rm=TRUE))

print("**************************")
print("Products with Price NA")

print(product[is.na(product$price),])

product[is.na(product$price),"price"]<-0

print("**************************")
print("Structure of Product Data Frame")
str(product)

print("**************************")
ids<-1:5
names<-c("Ram","Sita","Arun","Tarun","Yuva")
salary<-c(23454,12344,89898,45667,40000)
desig<-c("SE","SE","SSE","TL","Mgr")

employeeDB<-data.frame(
  "Empid"=ids,
  "EmpNames"=names,
  "Salary"=salary,
  "Designation"=desig,
  stringsAsFactors = FALSE
)

patientData<-data.frame()

#patientData<-edit(patientData)
#nrow(patientData)
#ncol(patientData)
#length(patientData)

sink()





