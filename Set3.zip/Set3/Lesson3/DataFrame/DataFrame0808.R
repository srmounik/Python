# Data Frame - Represents a tabular data

products<-data.frame(
  "prodId"=101:105,
  "Name"=c("Pen","Books","iPhone","Tablet","Watch"),
  "Price"=c(35,678,98899,34566,988),
  "inStock"=c(T,T,F,T,T),
  stringsAsFactors = FALSE
)

str(products)

