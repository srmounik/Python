ids<-101:106
names<-c("Ram","Sita","Krish","Yuva","Ravan","Lakshman")
salary<-c("Tim"=78745,"Ian"=2322,"Beth"=78788)
salary<-c(78745,2322,78788,12345,90967,58378)
desig<-c("SE","SSE","TL","SE","SE","SSE")

employee<-data.frame(
  empId=ids,
  empNames=names,
  empSal=salary,
  empDesig=desig,
  stringsAsFactors = FALSE
)
print(employee)

str(employee)

employee[3,2]<-"Shiva"


accountDF<-data.frame(
  accId=3:7,
  accNames=c("Tim","Jack","David","Steve","Brian"),
  balance=c(2345,5657,1213,87887,3434),
  stringsAsFactors = FALSE
)
print(accountDF)

str(accountDF)
