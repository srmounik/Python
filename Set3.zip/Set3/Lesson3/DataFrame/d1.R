marks<-c(34,89,45,90,23) //23,34,45,89,90
t1<-quantile(marks)
print(t1)

marks<-c(12,14,15,18,20,50,67,34,89,100)
t1<-quantile(marks)
print(t1)

x<-quantile(c(1,2),probs=c(0.4,0.5,0,1,0.75))
print(x)