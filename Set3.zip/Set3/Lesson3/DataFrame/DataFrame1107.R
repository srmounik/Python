empid<-101:106
names<-c("Ram","Sita","Lakshmi","Ganesh","Vishnu","Shiva")
salary<-c(34545,34545,89899,76767,23000,66767)
desig<-c("SE","SE","Mgr","TL","SSE","TL")


employeeData<-data.frame(
  "EmployeeId"=empid,
  "EmployeeName"=names,
  "Salary"=salary,
  "Designation"=desig,
  stringsAsFactors = FALSE
)

print(employeeData)

write.csv(employeeData,"Emp.csv")


employeeData[1,3]
names<-employeeData[,2]
print(names)
is.vector(names)

employeeData[3,]

employeeData[c(1,3,5),]

employeeData[,2:4]

employeeData$Designation

employeeData$Salary

employeeData$Salary[3]

# Key in the values using a spread sheet

account<-data.frame()
account<-edit(account)

print(month.abb)
print(month.name)
print(state.name)
print(state.abb)
print(letters)

Sys.Date()



install.packages("lubridate")




