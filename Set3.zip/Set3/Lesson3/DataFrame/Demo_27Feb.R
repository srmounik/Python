#dfrm <- read.table("input.txt",header=TRUE,
                   stringsAsFactor=FALSE,
                   na.strings=c("-",";","=","NA") )
dfrm

library(dplyr)
#select(dfrm,FirstName,Year1)
#filter(dfrm,!is.na(FirstName))
#filter(dfrm,Year2>2000)



#print(airquality$Ozone)


d1<-data.frame(
  1:5,
  c("Ram","Sita","Lakshman","Shiva","Vishnu")
)
print(d1)

patientData<-data.frame()
patientData<-edit(patientData)
print(patientData)
patientData<-edit(patientData)
print(patientData)
str(patientData)

patientData$isDiabetic<-as.logical(patientData$isDiabetic)
str(patientData)


#Employee Data
emp.data<-data.frame(
  empid=101:120,
  names=c("Ram","Sita","Lakshman","Shiva","Vishnu","Sai","Karan","Taman",
           "Lava","Kusha","Ravan","John","David","Akthar","Devi","Shaina",
           "Steve","Bravo","Sumith","Amar"),
  salary=c(90987,2345,67898,12345,67667,45654,34878,20956,23095,34756,
            53029,12756,98367,34556,39779,45455,75345,9253,67645,23556),
  desig=c("SE","SSE","TL","Mgr",
           "SE","SE","SSE","TL","SSE","SSE","TL","Mgr",
           "SE","SSE","TL","SE","SE","SE","SE","SSE"),
  stringsAsFactors = FALSE
)
#Access employees whose salary is <50000
emp.data[emp.data$salary<50000,]

#Access employee names and salary whose salary is <30000
emp.data[emp.data$salary<30000,c("names","salary")]

#install.packages(c("ggplot2","lattice","dplyr","sqldf"))
# Install the package: - One time activity
install.packages("imager")
#install.packages("dplyr") # Package name in ""

# Load a package - everytime it has to be done
library(dplyr) # package name doesnt have ""

select(emp.data)
select(emp.data,names,salary) #Select Columns - names,salary
select(emp.data,names,salary,desig) 

filter(emp.data,grepl("m",names)) # filtering the rows 
filter(emp.data,salary<30000)

filter(emp.data,grepl("S",names))

#Get only name and id of employees whose salary<30000
select(filter(emp.data,salary<30000),empid,names,salary)

arrange(emp.data,names)
arrange(emp.data,desc(names))
arrange(emp.data,salary)
arrange(emp.data,desc(salary))

#Get only name and id of employees whose salary<30000 arrange by names
arrange(select(filter(emp.data,salary<30000),empid,names),names)

group_by(emp.data,desig)

summarise(group_by(emp.data,desig),sum(salary))

summarise(group_by(emp.data,desig),min(salary))

summarise(group_by(emp.data,desig),mean(salary))

#Find the sum of salary grouped by designation
res<-summarise(group_by(emp.data,desig),sum(salary))
res[res$`sum(salary)`>100000,]

# Feature Pipe %>% - dplyr package

arrange(select(filter(emp.data,salary<30000),empid,names),names)

emp.data%>%select(names,salary) # select(emp.data,names,salary)

emp.data%>%filter(salary<30000)%>%select(empid,names,salary)%>%arrange(names)

emp.data%>%group_by(desig)%>%tally()

emp.data%>%count(desig)
table(emp.data$desig)

#Group the employees based on Desig having count >3

emp.data%>%group_by(desig)%>%tally()%>%filter(n>3)


emp.data<-data.frame(
  empid=101:105,
  names=c("John","Emma","Abraham","Paul","Ian"),
  salary=c(90987,2345,67898,12345,67667),
  desig=c("SE","SSE","TL","Mgr","SE"),
  stringsAsFactors = FALSE
)

emp.data<-mutate(emp.data,gender=c("Male","Female","Male","Male","Male"))

emp.data<-mutate(emp.data,tax=salary*12/100)

emp.data<-emp.data%>%mutate(GST=salary*2/100) # Derived columns

#Find the count based on Desig and gender
emp.data%>%group_by(gender,desig)%>%tally()
emp.data%>%group_by(desig,gender)%>%tally()

#Adding rows and columns to a df -rbind,cbind
newEmp<-list(565,"Oliver",45454,"TL","Male")
emp.data<-rbind(emp.data,newEmp)
 

locs<-c("Delhi","Chennai","Mumbai","Delhi","Chennai","Mumbai","Delhi","Chennai","Mumbai",
        "Delhi","Chennai","Mumbai","Delhi","Chennai","Mumbai","Delhi","Chennai","Mumbai",
        "Delhi","Pune","Chennai")

emp.data<-cbind(emp.data,location=locs)

emp.data%>%group_by(location,desig)%>%tally()

emp.data%>%select("names","salary")%>%filter(salary<30000)%>%arrange(salary)

head(emp.data,5)
tail(emp.data,4)

#Oracle or SQL syntax to query a table - package sqldf - query a dataframe
install.packages("sqldf")
library(sqldf)

#Access all rows of employee data

employee<-data.frame(
  empid=101:120,
  names=c("Ram","Sita","Lakshman","Shiva","Vishnu","Sai","Karan","Taman",
          "Lava","Kusha","Ravan","John","David","Akthar","Devi","Shaina",
          "Steve","Bravo","Sumith","Amar"),
  salary=c(90987,2345,67898,12345,67667,45654,34878,20956,23095,34756,
           53029,12756,98367,34556,39779,45455,75345,9253,67645,23556),
  desig=c("SE","SSE","TL","Mgr",
          "SE","SE","SSE","TL","SSE","SSE","TL","Mgr",
          "SE","SSE","TL","SE","SE","SE","SE","SSE"),
  stringsAsFactors = FALSE
)
employee<-mutate(employee,gender=c("Male","Female","Male","Male",
                                   "Male","Female","Female","Male",
                                   "Male","Female","Male","Female",
                                   "Male","Male","Male","Male",
                                   "Female","Male","Male","Male"))
newEmp<-list(565,"Oliver",45454,"TL","Male")
employee<-rbind(employee,newEmp)
employee<-cbind(employee,location=locs)

sqldf("Select * from employee")

sqldf("select empid,names,location from employee")

sqldf("select empid,names,location from employee
      where salary>60000")

sqldf("select empid,names,location from employee
      where salary>60000
      order by names desc")

sqldf("select location,count(*) as COUNT
      from employee
      group by location")

sqldf("select location,gender,count(*)
      from employee
      group by location,gender")

sqldf("select location,gender,desig,count(*)
      from employee
      group by location,gender,desig")


gradeTable<-data.frame(
  desig=c("SE","SSE","TL","Mgr"),
  grade=c("A1","A2","C1","C2"),
  minSal=c(20000,30000,45000,60000),
  maxSal=c(32000,46000,65000,80000)
)

print(employee)
print(gradeTable)

sqldf("select names,employee.desig,grade
       from employee,gradeTable
       where names=='Ram' and
       employee.desig==gradeTable.desig
      ")

#Find the employees who earn more than Sai

sqldf("Select salary from employee where names='Sai'")

#salary of Sai - "Select salary from employee where names='Sai'"
sqldf("select * from employee where
      salary > (Select salary from employee where names='Sai')")

subset(employee,salary>50000,select=c("names","salary"))


library(pdftools)

txt <- pdf_text("Demo1.pdf")
print(txt)



