# Data Frame - 2 dimensional DS , rows and columns, columns are of same type

accid<-3:8
custName<-c("Ram","Lakshman","Bharat","Chratrug","Sita","Ravan")
balance<-c(34345,8989,23788,9090,62538,1000)
isActive<-c(T,T,F,T,T,T)

accountData<-data.frame(
  "AccountId"=accid,
  "Customer"=c("Ram","Lakshman","Bharat","Chratrug","Sita","Ravan"),
  "AccountBalance"=balance,
  "Active"=isActive,
  stringsAsFactors = FALSE
)

print(accountData)


emp<-data.frame(
  "EmployeeId"=1:4,
  "EmployeeName"=c("Tina","Lina","Anu","Shiny"),
  "Salary"=c(3434,2323,9090,7677),
  stringsAsFactors = FALSE
)

str(emp)

accountData[1,2]
accountData[3,]
accountData[,2]

accountData[c(1,3),c(2,4)]

#$ Notation

accountData$Customer

accountData$Customer[3]
accountData$AccountBalance
ncol(accountData)
nrow(accountData)

