# Factor is useful for vectors that have categorical data

desig<-c("SE","SSE","SE","SSE","TL",
         "Mgr","SSE","SSE","Mgr","TL",
         "SE","SSE","TL","Mgr","SE","SSE","SE","SSE","TL",
         "Mgr","TL","SSE")

is.factor((desig))

fdesig<-factor(desig)
# 1) Count the unique values in desig - "SE", "SSE","TL","Mgr"
# 2) Sort the values -  "Mgr","SE", "SSE","TL"
# 3) The sorted values are called levels 
# 4) Levels : 1- "Mgr",2- "SE",3- "SSE",4-"TL"
# 5) Internally the data in desig is stored based on levels into fdesig
# 6) "SE","SSE","SE","SSE","TL","Mgr","SSE","SSE","Mgr","TL"...
# 2,3,2,3,4,1,3,3,1,4...

print(fdesig)

str(fdesig)
is.factor((fdesig))

fdesig[2]
fdesig[2]<-"TL"

fdesig[6]
fdesig[6]<-"Sr.Mgr"
print(fdesig)

# The data in the factor can accept only the values which are there in the level

levels(fdesig)<-c(levels(fdesig),c("Sr.Mgr","VP"))

fdesig[6]
fdesig[6]<-"Sr.Mgr"
print(fdesig)

#When u create a factor mention the levels
fdesig<-factor(desig,levels = c("SE","SSE","TL","Mgr","Sr.Mgr","Direc","AVP","VP"))
print(fdesig)

table(fdesig)

fdesig[5]<-"VP"

table(fdesig)

fdesig[grepl("SSE",fdesig)]

