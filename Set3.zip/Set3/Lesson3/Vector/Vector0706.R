patientWeight<-c(89,74,55,76,63,50,90,67,55)

#Sort in ascending and give the index: 6,3,5,8,2,4,1,7

order(patientWeight,decreasing = TRUE) # Index of the elements

patientWeight[c(6,3,5,8,2,4,1,7)]

patientWeight[order(patientWeight)]

patientWeight[patientWeight==50]
patientWeight[patientWeight>70]

ratings<-c("Ram"=2,"Anil"=2,"Arun"=1,"Abhay"=1,"Akash"=1,"Tarun"=3)
ratings[ratings==1]
