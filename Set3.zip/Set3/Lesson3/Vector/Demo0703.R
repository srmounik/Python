#Function to create a vector -c()
marks<-c(10,20,30,40)
class(marks)

enames<-c("Ram","Sita","Arjun")
print(enames)

v1<-c(2,45,TRUE,5+8i,"Hello","Ram")
print(v1)
typeof(v1)
length(v1)

v1<-c(2L,45.9,TRUE,5+3i)
print(v1)
typeof(v1)

v1<-c(2L,45,TRUE,8.45)
print(v1)
typeof(v1)

v1<-c(2L,45L,TRUE)
print(v1)
typeof(v1)

# There are no scalars in R - everything is a vector
age<-45 # age is a numeric vector with 1 element

pid<-c(109,345)

# Vector index starts with 1
marks<-c(10,20,30,40)
class(marks)
marks[1]

# How to create a vector
# c function

salary<-c(45435,1224,789789,34236,34556,92858)
print(salary)

#seq,sequence
orderId<-90:97
print(orderId)

tokenId<-seq(40,80,by=3)
print(tokenId)

v1<-rep(6,20)
print(v1)

accId<-c(101:105,rep(6,3),seq(10,50,by=5),c(2,5,9))
print(accId)

temp<-c(34,40,32,28,29,19,31)
print(temp)
#There are 7 values in temp for which u can give names
names(temp)<-c("Sun","Mon","Tues","Wed","Thur","Fri","Sat")
print(temp)

price<-c("TV"=567,"Pen"=20,"Book"=89,"Pouch"=109,"Food"=45)
print(price)

price1<-c("TV"=567,20,"Book"=89,109,"Food"=45)
print(price1)

#Accessing the elements of a vector
pid<-c(34,768,12,228,396,90,109,5673,72,910,43)

#Vector index starts with 1
pid[1]
pid[5]
#Access 1,4,7,3 element in a vector
pid[c(1,4,7,3)]
pid[seq(1,11,by=2)]
pid[c(2,10)]
#Get me all elements except the 6th element
pid[-6]

#Get me all elements except the 6th,2nd and 10th element
pid[-c(6,2,10)]

# You cannot mix +ve and -ve
pid[6,-2]

# Access vector using Logical values
pid<-c(34,768,12,228,396,90,109,5673,72,910,43)
pid[c(T,F,T,F,T,T,T,F,F,F,T)]
pid[c(F,T)] #Recycle rule F,T,F,T,F,T,F,T,F,T,F,T

#Access the vector using Character index, if there is a name
price<-c("TV"=567,"Pen"=20,"Book"=89,"Pouch"=109,"Food"=45)
print(price)
price[1]
price[c(1,3,4)]
price[c(T,F,F,T,T)]
price["Pen"]
price[c("Pouch","TV")]
#Invalid price[-c("Pen")]
price[price>100]
price[price<50]


temp<-c(34,40,32,28,29,19,31)
print(temp)
#There are 7 values in temp for which u can give names
names(temp)<-c("Sun","Mon","Tues","Wed","Thur")
print(temp)

temp["Mon"]<-55

temp[1:4]

print(month.name)
print(month.abb)
print(state.name)
print(state.abb)

month.name[2:7]

marks<-c(45,12,76,98,44,90,39,24)
print(marks)

marks[marks<40]<-50
print(marks)

print(marks)
marks<-marks[-2]
print(marks)
marks<-NULL

mean(marks)
sum(marks)
min(marks)
which.min(marks)
max(marks)
range(marks)
marks[order(marks)]
sort(marks,decreasing = TRUE)

sort(month.name)

n1<-c(67,23,12,50)
order(n1) #12,23,50,67 ->3,2,4,1

tax<-c(5654,3455,NA,4353,85697,NA,23423)
print(tax)
sum(tax,na.rm = TRUE)
mean(tax,na.rm=TRUE)
sort(tax)

v1<-c(10,20,NA)
sum(v1,na.rm = TRUE)
mean(v1,na.rm = TRUE) # remove NA c(10,20), mean=10+20/2
mean(v1)


v1<-c(1,4,6,9,5)
v2<-c(10,3,7,2,6)
v1+v2
v1-v2
v1*v2
v1/v2
v1&v2
v1&&v2

v1<-c(1,4,6,9,5)
v2<-c(5,10)
v1+v2 #Recycle rule v2<-c(5,10,5,10,5,10)

print(marks)
index<-10
marks*index

print(v1)
print(v2)
v3<-c(v1,v2)
print(v3)






