# Data Structures

# Vector is a 1 dimensional collection of homogeneous elements

employees<-c("Ram","Krish","Sita","Ravan") # c() is used to create a vector

typeof(employees)
class(employees)

salary<-c(10899,34556,20900,14546,47899,29899)
print(salary)
length(salary)
is.vector(salary)

age<-10 # age is a vector containing 1 element
is.vector(age)

fname<-"Hema"
is.vector(fname)

inStock<-c(T,F,T,T,F,T)

# Create a vector - c()
empid<-101:107
print(empid)

months<-seq(10,40,by=2)
print(months)

data<-rep(c(6,7,9),8)
print(data)

score<-c(56,23,90,12,80,76)
print(score)

sales<-c(201:204,seq(300,306),rep(400,3),45,900,632)
print(sales)

# Vector index starts with 1

v1<-c("Hello",67,TRUE)
print(v1)

v2<-c(65.34,90,TRUE)

#First create the vector and then give names
sales<-c(678,345,900,102)
print(sales)
names(sales)<-c("Allen","Sam","Ram","Sita")
print(sales)

marks<-c("Python"=20,"RPrg"=40,"DevOps"=33,"ML"=34,"AI"=50,"Cloud"=12)
print(marks)

salary<-c(10899,34556,20900,14546,47899,29899)
# Accessing the vector

# Integer index
marks[2]
salary[4]
salary[2:5] # 2,3,4 and 5
marks[4:5]

marks[c(1,6)] # 1st and 6th mark
marks[c(2,5)] # 2nd and 5th mark

salary[c(4,1,3)]

# Integer Negative index

marks[-2] # Gimme all amrks except the 2nd mark
marks[-(1:3)] # Dont give me 1,2 and 3rd mark

marks[2,-3]

# logical index
salary<-c(10899,34556,20900,14546,47899,29899)
salary[c(T,F,T,T,T,F)]
salary[c(F,T)] # Recycle rule F,T,F,T,F,T

#Character Index
salary["Ram"] #Invalid as salary doesnt have name

sales<-c(678,345,900,102)
print(sales)
names(sales)<-c("Allen","Sam","Ram","Sita")
print(sales)

marks<-c("Python"=20,"RPrg"=40,"DevOps"=33,"ML"=34,"AI"=50,"Cloud"=12)
print(marks)

marks["DevOps"]
marks[c("ML","Python","AI")]
sales["Sita"]

print(month.name)
print(month.abb)

climate<-c(23,34,34,32,45,46,43,38,33,29,20,10)
names(climate)<-month.abb
print(climate)

# Climate for q3
climate[7:9]
climate[c("Jul","Aug","Sep")]

# Change June climate to 30
climate["Jun"]<-30
print(climate)

# Set the marks in Sub 2 and 3 as 100
marks<-c("Python"=20,"RPrg"=40,"DevOps"=33,"ML"=34,"AI"=50,"Cloud"=12)
print(marks)

marks[2:3]<-100
print(marks)

# Delete the AI marks
marks<-marks[-5]
print(marks)

# Vector functions
print(climate)
sort(climate)
sort(climate,decreasing = TRUE)
min(climate)
max(climate)
range(climate)
which.min(climate) # index of the minimum element
which.max(climate) # index of the maximum element


salesA<-c(56,30,90,10,20)
salesB<-c(34,78,90)

# To combine the elements of a vector use c()
totalsales<-c(salesA,salesB)
print(totalsales)

sum(totalsales)
prod(totalsales)
mean(totalsales)

v1<-c(5,9,NA,2,3,NA,10)
print(v1)

sum(v1) # If a vector contains NA, the sum is also NA
sum(v1,na.rm = TRUE)

min(v1,na.rm = TRUE)
max(v1,na.rm = TRUE)

prod(v1,na.rm = TRUE)

print(v1)
# Make all NA's in v1 as 40
v1[is.na(v1)]<-40
print(v1)

# Arithmetic Ops on vectors

n1<-c(6,2,3,4,5)
n2<-c(8,9,10,0,1)

n1+n2
n1-n2
n1*n2
n1/n2

n1&n2
n1&&n2 # 1st element of n1 && 1st element of n2


n1<-c(6,2,3,4,5)
n2<-c(8,9) # 8,9,8,9,8,9
n1+n2  # repeat n2 to fill in all the remaining in n1

n1<-c(6,2,3,4,5,10) # len=6
n2<-c(8,9) # 8,9,8,9,8,9 , len=2
n1+n2
n1-n2
n1*n2
n1/n2
n1&n2

5*n1


