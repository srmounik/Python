# Vector - 1 dimensional DS, of same type

#Creating a vector
marks<-c(67,34,99,12,90)
typeof(marks)
class(marks)
length(marks)

# c() function is used to create a vector

empNames<-c("Ram","Sita","Lakshman","Ravan","Bharath")
typeof(empNames)
str(empNames)

empid<-107:115
print(empid)
str(empid)

orderId<-seq(67,100,by=4)
print(orderId)

rating<-rep(1,7)
print(rating)

prodPrice<-c(23:28,seq(100,120,by=3),rep(125,4),178,190,240)
print(prodPrice)
length(prodPrice)

# There are no scalars in R - every variable in R is a vector
age<-40 # Age is a vector having 1 element
company<-Capgemini # company is a character vector having 1 element


v1<-1:5
v2<-c(8,12,20)
v3<-c(v1,v2)
print(v3)

#Elements of a vector should be of same type
#All the elements will be converted to the same type

emp<-c(101L,"Lakshmi",89898.89,TRUE)
print(emp)

# We can give names for the vector elements

marks<-c(67,34,99,12,90)
print(marks)

names(marks)<-c("Maths","Physics","Chem","Biology","CS")
print(marks)

price<-c("Pen"=89,"LCD"=34545,"Camera"=56767,"iPad"=9000,
         "Shirt"=565,"Tab"=23456,"shoes"=787,"Book"=200)
print(price)
print(names(price))

#Accessing the elements

#Numeric index - starts with 1
sales<-c(345,235,890,123,758,340,100,565,400,300,934,111,298,543)
sales[1]
sales[7]
sales[c(1,7)]
sales[c(3,8,1,4,5)]
sales[-4] # All except 4
sales[-c(1,2,3,4,5)]
sales[-c(3,5,6)]
sales[4:7]
sales[-c(4:7)]

sales[c(-4,2)] #Invalid

price[2]
price[1:4]


#logical index
price<-c("Pen"=89,"LCD"=34545,"Camera"=56767,"iPad"=9000,
         "Shirt"=565,"Tab"=23456,"shoes"=787,"Book"=200)
sales<-c(345,235,890,123,758,340,100,565,400,300,934,111,298,543)

length(price)
price[c(T,F,F,T,F,F,T,T)]
sales[c(T,F)] # 2 values, but sales has 14 elements, so repeat T,F 7times 
sales[c(T,F,T)] # 3 values, but sales has 14 elements, 14 is not a multiple of 3


#Character index - only if the vector elemsnt have names
price<-c("Pen"=89,"LCD"=34545,"Camera"=56767,"iPad"=9000,
         "Shirt"=565,"Tab"=23456,"shoes"=787,"Book"=200)

price["LCD"]
price[c("shoes","iPad","Pen")]
marks["Chem"]

#Conditional access
price[price<90]
price[price<5000]
price[grepl("e",names(price))]
price[grepl("oo",names(price))]

names(price)<-NULL
print(price)

#Modifying the vector elements

price<-c("Pen"=89,"LCD"=34545,"Camera"=56767,"iPad"=9000,
         "Shirt"=565,"Tab"=23456,"shoes"=787,"Book"=200)
sales<-c(345,235,890,123,758,340,100,565,400,300,934,111,298,543)

price["iPad"]<-10000

print(price)

price[price<500]<-650
print(price)
 
price<-price[-7] # Removing the 7th element from the vector

#Functions on vector
min(price)
max(price)
which.min(price)
which.max(price)
which(grepl("LCD",names(price)))
which(grepl("oo",names(price)))
which(grepl("e",names(price)))
which(price<200)
which(price==34545)

order(price) #index order for sorting
sort(price)
sort(price,decreasing=TRUE)
price[sort(names(price))]

sum(price)
mean(price)

sales<-c(345,235,890,123,NA,758,340,100,565,NA,400,300,NA,934,111,NA,298,543)
length(sales)

min(sales,na.rm = TRUE)
max(sales,na.rm=TRUE)
sum(sales,na.rm=TRUE)

sales[!is.na(sales)]
which(is.na(sales))

prod(c(1,7,2,8))

#Vector arithmetics

v1<-c(5,6,7,8)
v2<-c(2,9,10,7)

v3<-c(v1,v2)

v1+v2
v1-v2
v1*v2
v1/v2


v1<-c(5,6,7,8,12,3) # length=6
v2<-c(2,9,10,7) #length=4  recycle (2,9,10,7,2,9,10,7)

#Recycle rule
v1+v2 

v1<-c(1,4,3)
v2<-c(2,10,5)
sum(v1,v2)

prod(v1,v2)

8*v1


v1<-c(1,4,3)
v2<-c(2,10,5)

prod(v1,v2)# 1*4*3*2*10*5
v1*v2 #1*2, 4*10, 3*5


v2 <- c(3,5,7,10,4,8,13,3,2)

# we can create two intermediate vectors
ordIdxs <- order(v2)
sortedV2 <- v2[ordIdxs]

# then use them as follows :
ordIdxs[indexesInRangeNumeric(sortedV2,2,4)]

# this returns the same indexes :
# N.B. : 'which' returns ascending indexes while the previous line does not:
# sort the result if you want them ascending
which(v2 >= 2 & v2 <= 4)






