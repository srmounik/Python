ids<-1:10
print(ids) #Numeric vector
length(ids)

token<-seq(8,80,by=4)
print(token)

r1<-rep(6,4)
print(r1)

#Vector is a 1Dimensional Data structure - elements of same type

age<-12 #Vector containing 1 element
length(age)

name<-"Capgemini" #Character Vector of 1 element
length(name)

#Creating vector - c()
names<-c("Ram","Sita","Lakshman","Ravan","Krish")
length(names)
print(names)
str(names)

marks<-c(34,78,12,90,45,72,94,33,20,77,59)
print(marks)
length(marks)
sum(marks)
mean(marks)
sort(marks)
sort(marks,decreasing = TRUE)


#Vector with different types
v1<-c(56,"Allen",89+8i,TRUE)
print(v1)

v2<-c(56,90L,89,TRUE)
print(v2)

v2<-c(56L,90L,89L,TRUE)
print(v2)

v2<-c(56,90L,89+7i,TRUE)
print(v2)

temp<-c(c(1,2,3,8),c(7,10,15,21),c(20,60,70))
print(temp)

temp<-c(1:5,seq(12,15),rep(20,4),c(45,82,100))
print(temp)

#Index starts with 1

marks<-c(34,78,12,90,45,72,94,33,20,77,59)
#Numeric index
marks[1]
marks[1:5]
marks[7:9]
marks[c(2,8,10)]
marks[4]

#Negative Index
marks[-3]
#Dont want the odd marks
marks[-c(1,3,5,7,9,11)]
marks[-seq(1,11,by=2)]

marks[c(3,-4)]

#Logical Index
marks[c(T,T,T,F,F,T,F,T,F,T,T)]

marks[c(F,T)]

#Condition
marks[marks<50]
marks[marks>70]
marks[(marks<80)&(marks>70)]


names1<-c("Ram","Sita","Lakshman","Ravan","Krish")
names1[c(grep("i",names1))]

#Character Index
price<-c(34566,12,89,8934)
names(price)<-c("LCD","Pencil","Pen","Smart Phone")
print(price)


#accountBalance<-c(78999,10000,15000,45000)
accountBalance<-c("Ram"=78999,"Sita"=10000,"Ravan"=15000,"Lakshman"=45000)

rainfall<-c(12,23,45,56,67,90,89,87,65,45,40,33)
names(rainfall)<-month.abb
print(rainfall)

accountBalance["Ram"]
accountBalance[2]
accountBalance[c("Ram","Ravan")]

accountBalance[c(grep("m",names(accountBalance)))]
rainfall[4:8]
rainfall[c("Jan","Jun","Dec")]
rainfall[-c(4:8)]

unname(rainfall[4:8])

print(marks)
# Change all marks < 50 to 35

marks[marks<50]<-35
print(marks)

marks[4]<-60


v1<-c(5,3,9,12,6)
v2<-c(2,8,10,1,7)
v1+v2
v1-v2
v1*3
v1/4
v1*v2


v1<-c(5,3,9,12,6) #Length=6
v2<-c(1,2,4) #Length=2, repeat the elements in v2, 1,2,4,1,2,4
v1+v2 #Recycling rule
v1-v2
v1*v2
v1/v2

sem2Marks<-c(56,34,67,90,20)
print(marks)
print(sem2Marks)

allMarks<-c(marks,sem2Marks)
print(allMarks)

sum(allMarks)

mean(allMarks)

min(allMarks)

max(allMarks)

allMarks[order(allMarks,decreasing = TRUE)]

price<-c("TV"=10000,"LCD"=20000,"Book"=NA,"Dress"=NA,"Pen"=20,"Pencil"=5,"Bag"=700)
print(price)
sum(price,na.rm = TRUE)
mean(price,na.rm = TRUE)
min(price,na.rm = TRUE)
price[order(price,na.last = FALSE)]
which(is.na(price))
which.min(price)
sum(is.na(price))

sort(allMarks)

checkLength<-function(x){
  nchar(x)>5
}

names<-c("Ram","Sita","Lakshman","Ravan","Krishna")

names[checkLength(names)]











