n1<-11:20
class(n1)
typeof(n1)
is.vector(n1)
length(n1)
str(n1)

#These objects are always vectors: there are no scalars in R.
age<-45L #Is a vector containing 1 element
name<-"Ram" #A vector containing 1 element of type char
is.vector(name)

#Creating Vectors - c()
marks<-c(56,89,23,90,78)
length(marks)

empid<-101:115

score<-seq(7,25,by=3)
print(score)

v1<-rep(6,3)
print(v1)

demo1<-c(1:4,seq(8,12),rep(6,4),34,21,90,seq(10,40,by=10))
print(demo1)

empNames<-c("Ram","Sita","Krish","Vinu")
status<-c(T,F,T,T,TRUE,FALSE)

v1<-c(5,2,9)
v2<-c(12,6,4)
v3<-c(v1,v2)

temp<-c(4,"Hello",TRUE,8+7i)
print(temp)

temp<-c(4,TRUE,8+7i)
print(temp)

temp<-c(4,TRUE)
print(temp)


# Elements in a vector can have names
marks<-c(56,89,23,90,78)
print(marks)

marks<-c("Arun"=56,"Steve"=89,"Edison"=23,"Winston"=90,"Sam"=78)
print(marks)

scores<-c(70,30,56,20)
print(scores)
names(scores)<-c("DevOps","Cloud","Spring","Python")
print(scores)

sales<-seq(100,1000,length.out = 12)
print(sales)
names(sales)<-month.abb
print(sales)

#Access the Vector
marks<-c("Arun"=56,"Steve"=89,"Edison"=23,"Winston"=90,"Sam"=78,"Tarun"=70,
         "Vijay"=63,"Nita"=59)
print(marks)

#Vector index starts with 1
#Positive Index
marks[1]
marks[5]
marks[c(1,5)]
marks[c(1,3,4,5)]
marks[2:4]

#Negative Index
marks[-3]
marks[c(-1,-2,-3)]

marks[c(1,-4)] #Invalid

#Logical Index
marks[c(T,T,F,F,F,F,T,F)]
marks[c(T,F)]
marks[c(T,F,T)] # 8 values , T,F,T,T,F,T,T,F,T

#Character Index - only if ur vector has names
marks["Arun"]
marks[c("Arun","Sam","Nita")]

#Coniditional Access
marks[marks<50]

marks[marks>=64]

marks[(marks<80)&(marks>70)]

#Modify the elements

marks<-c("Arun"=56,"Steve"=89,"Edison"=23,"Winston"=90,"Sam"=78,"Tarun"=70,
         "Vijay"=63,"Nita"=59)
print(marks)

sum(marks)
mean(marks)

marks[4]<-100
marks["Nita"]<-61
marks[c(6,7)]<-50
marks[marks<60]<-65

#Delete Arun and Steve's mark
marks<-marks[c(-1,-2)]

marks<-NULL

accBalance<-c(2000,1000,NA,500,200,NA,800)
print(accBalance)

length(accBalance)
sum(accBalance,na.rm = TRUE)
mean(accBalance,na.rm = TRUE)
prod(accBalance,na.rm=TRUE)

min(accBalance,na.rm=TRUE)
which.min(accBalance)

max(accBalance,na.rm=TRUE)
which.max(accBalance)

range(accBalance,na.rm = TRUE)

#Order - index of elements in ascending order
order(accBalance)
accBalance[order(accBalance,decreasing = TRUE)]

sort(accBalance,decreasing = TRUE)[3]

sort(accBalance,decreasing = TRUE)[2]

sort(accBalance)[2]

max(accBalance[accBalance < max(accBalance,na.rm = TRUE)],na.rm = TRUE) 


marks<-c("Arun"=56,"Steve"=89,"Edison"=23,"Winston"=90,"Sam"=78,"Tarun"=70,
         "Vijay"=63,"Nita"=59)
print(marks)

marks[sort(names(marks))]

sort(marks)

names1<-c("Ram","Sita","Lakshman","Ravan","Krish")
sort(names1)
names1[c(grep("i",names1))]


v1<-c(8,4,3,1)
print(v1)

v1<-c(v1,5)
print(v1)

v1<-c(v1,c(10,30))
print(v1)





accBalance<-c(2000,1000,NA,500,200,NA,800)
print(accBalance)

length(accBalance[is.na(accBalance)])

marks<-c("Arun"=56,"Steve"=89,"Edison"=23,"Winston"=NA,"Sam"=78,"Tarun"=NA,
         "Vijay"=NA,"Nita"=59)
print(marks)

length(marks[!is.na(marks)])

v1<-c(5,3,9,1)
v2<-c(10,4,8,7)
v1+v2
v1-v2
v1*v2
v1/v2
4*v1

#length(v1) is 7 and length(v2) is 4
v1<-c(5,3,9,1,2,11,14)
v2<-c(10,4,8,7) # v1 has 7 elements so repeat v2 10,4,8,7,10,4,8,7
v1+v2
v1-v2

#length(v1) is 8 and length(v2) is 4
v1<-c(5,3,9,1,2,11,14,12)
v2<-c(10,4,8,7) # v1 has 8 elements so repeat v2 10,4,8,7,10,4,8,7
v1+v2
v1-v2








