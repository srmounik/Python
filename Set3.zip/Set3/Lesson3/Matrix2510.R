# Matrix - 2 dimensional data structure
 
v1<-c(89,34,67,10,22,77,45,33,23,65,100,49)

# Matrix 3 rows and 4 cols and in that populate v1
# Data is populated in columnar manner
m1<-matrix(v1,nrow=3,ncol=4)
print(m1)

m2<-matrix(v1,nrow=3,ncol=4,byrow = TRUE)
print(m2)

r1<-c("Allen","Alice","Anuj")
c1<-c("DevOps","Cloud","Python","R")

marks<-matrix(v1,nrow=3,ncol=4,byrow = TRUE,
              dimnames = list(c("Allen","Alice","Anuj"),
                              c("DevOps","Cloud","Python","R")))
print(marks)


BankInterest<-matrix(
  c(12.34,56,78,90,30,44,18.95,40),
  nrow=2,
  dimnames=list(
    c("Account1","Account2"),
    c("Q1","Q2","Q3","Q4")
  )
)
print(BankInterest)

# Access the matrix
print(marks)
marks[1,2]
marks[3,4]

#Access all the data in 2nd row
marks[2,]

# Access the 3rd column
marks[,3]

#Access 1sta nd 2nd row of 4th column
marks[c(1,2),4]

# 1sta bd 2nd row : 2nd and 4th column

marks[c(1,2),c(2,4)]

marks[-1,-3]

marks[-2,c(-1,-3)]

marks["Allen",]
marks["Allen","Python"]
marks[,"Cloud"]

marks[marks<50]

which(marks<50,arr.ind = TRUE)

marks[which(marks<50,arr.ind = TRUE)]

# Combine two matrices

marks<-matrix(v1,nrow=3,ncol=4,byrow = TRUE,
              dimnames = list(c("Allen","Alice","Anuj"),
                              c("DevOps","Cloud","Python","R")))
print(marks)

# Two more people take the test

newMarks<-matrix(c(56,67,78,89,90,80,70,60),
                 ncol=4,
                 dimnames=list(c("Devi","Suraj"),c1))
print(newMarks)

marks<-rbind(marks,newMarks)
print(marks)

Veena<-c(33,22,11,44)

marks<-rbind(marks,Veena)
print(marks)

newTest<-matrix(70:81,nrow=6,dimnames = list(
  c(r1,"Devi","Suraj","Veena"),c("Angular","Spring")
))
print(newTest)

marks<-cbind(marks,newTest)
print(marks)



m1<-matrix(1:6,ncol=3)
print(m1)

m2<-matrix(1:6,ncol=2)
print(m2)

cbind(m1,m2)

# Matrix

m1<-matrix(1:6,ncol=3)
print(m1)

m2<-matrix(c(34,12,90,89,78,20),ncol=3)
print(m2)

m1+m2
m1-m2
m1*m2
m1/m2
t(m1)

print(marks)
print(t(marks))

rownames(marks)
colnames(marks)
dim(marks)






