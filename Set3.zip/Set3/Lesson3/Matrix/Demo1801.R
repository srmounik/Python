scores<-c(45,98,70,90,12,0,34,45,69,44,103,82)

# Layout the scores in a 4*3 matrix
scoresmatr<-matrix(scores,nrow=4,ncol=3)

scoresmatr

#Access the elements
scoresmatr[2,1]

scoresmatr[4,2]

# All the values in the 2nd row
scoresmatr[2,]

scoresmatr[c(1,2),]

# All the values in first column

scoresmatr[,1]

scoresmatr[,c(1,3)]

scoresmatr[c(3,4),c(1,2)]

m1<-matrix(1:10,nrow=5,ncol=4)
m1



rows<-c("Dhoni","Kholi","Pujara","Raina")
cols<-c("Match1","Match2","Match3")

scoresIPL<-matrix(
  scores,nrow=4,ncol=3,byrow=TRUE,dimnames = list(rows,cols))
scoresIPL

scoresIPL[4,2]
scoresIPL[2,]

scoresIPL[c("Kholi","Pujara"),c("Match1","Match3")]

scoresIPL

M4M5Scores<-matrix(c(34,56,98,67,56,45,34,12),nrow=4,dimnames = list(rows,c("Match4","Match5")))
M4M5Scores

ScoresFinal<-cbind(scoresIPL,M4M5Scores)
ScoresFinal

players<-c("Ashwin","Sundar")
colnames1<-c("Match1","Match2","Match3","Match4","Match5")
s2<-matrix(c(78,78,34,0,2,34,78,12,2,3),nrow=2,dimnames = list(players,colnames1))
s2


finalScores<-rbind(ScoresFinal,s2)
finalScores




