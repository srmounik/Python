# Matrix - 2D
# 1->Data, 2-> No of rows and columns

# Scores of 4 employees in 3 courses
scores<-c(23,34,45,56,12,78,87,65,90,80,60,50)

scoreMatrix<-matrix(scores,nrow=4,ncol=3)
print(scoreMatrix)

scoreMatrix1<-matrix(scores,nrow=4,ncol=3,byrow = TRUE)
print(scoreMatrix1)

#You can give names to rows and cols
rowNames<-c("Yuva","Kisha","Tara","Megha")
colNames<-c("DevOps","R Prog.","Angular")

dimnames(scoreMatrix)<-list(rowNames,colNames)
print(scoreMatrix)

# Store appraisal data of employees for 4 Q's of 3 yrs

appraisal<-matrix(
                  c(3,2,1,3,2,2,2,3,2,1,1,3),
                  nrow=3,
                  byrow=TRUE,
                  dimnames = list(
                    c("2016","2017","2018"),
                    c("Q1","Q2","Q3","Q4")
                  ))
print(appraisal)


#Accessing the matrix
print(scoreMatrix)
scoreMatrix[3,3]
scoreMatrix[2,1]

# Get me all the marks of Megha
scoreMatrix[4,]

# Get all the Angular marks
scoreMatrix[,3]

# Get all marks of Yuva and Tara
scoreMatrix[c(1,3),]

# Get DevOps and R marks of Yuva and Tara
scoreMatrix[c(1,3),c(1,2)]

# Megha marks for DevOps and R
scoreMatrix[4,c(1,2)]
scoreMatrix[4,1:2]
scoreMatrix["Megha",c("DevOps","R Prog.")]

scoreMatrix[,c(1,2)]


# Modify the elements of a matrix
print(appraisal)
#Change Q4 2018 rating to 2

appraisal["2018","Q4"]<-2
print(appraisal)

#How to add rows and columns
#Add 2 rows to indicate 2014 and 2015 data

data20<-matrix(c(1,1,1,1,2,2,2,2),
             nrow=2,
             byrow = TRUE,
             dimnames =list(
               c("2014","2015"),
               c("Q1","Q2","Q3","Q4")
               ) )
print(data20)


#rbind- row bind, will combine the rows of 2 matrices
appraisal5Yrs<-rbind(data20,appraisal)
print(appraisal5Yrs)

#cbind - to appraisal5Yrs, add overall rating
cbind(appraisal5Yrs,
      matrix(c(1,2,3,1,2),ncol=1,dimnames=list(c(),"Overall")))


#Simple matrix

m1<-matrix(1:15,nrow=3)
print(m1)
m1<-rbind(m1,21:25)
m1<-cbind(m1,c(40,50,60,70))
print(m1)

m1[3,]<-10
print(m1)

m2<-matrix(1:8,nrow=2)
m3<-matrix(11:18,nrow=2)
print(m2)
print(m3)
m2+m3
m2-m3
m2*m3
m2/m3

t(m2)

print(scoreMatrix)
which(scoreMatrix<=50,arr.ind = TRUE)
which(scoreMatrix==87,arr.ind = TRUE)
which(scoreMatrix<=50)


scoreMatrix[scoreMatrix<=50]<-63
print(scoreMatrix)




















