#Creating a matrix
#Two dimensional DS, rows and cols 

d1<-1:12
m1<-matrix(d1,nrow=4,ncol=3)
print(m1)

#Store the scores of 3 students in 5 modules

scores<-c(23,89,90,45,12,56,34,80,20,77,39,91,66,48,30)
ParticipantScore<-matrix(scores,nrow=3,ncol=5,byrow=TRUE)
print(ParticipantScore)


rownames1<-c("Ram","Sita","Ravan")
colnames1<-c("DevOps","Cloud","Python","Spring","Java")

dimnames(ParticipantScore)<-list(rownames1,colnames1)

print(ParticipantScore)

#Accessing the matrix - [rowindex,colindex]
ParticipantScore[1,4]
ParticipantScore[c(2,3),c(4,5)]
ParticipantScore[1:2,2:5]
ParticipantScore[2,3]
ParticipantScore[2,c(1,3,5)]

ParticipantScore[2,] #Get the second row
ParticipantScore[c(1,2),]#Get the first and second row
ParticipantScore[,3] #Get the third column
ParticipantScore[,c(1,2,4)]

ParticipantScore["Ram","Spring"]
ParticipantScore["Ram",]
ParticipantScore[,c("Cloud","Spring")]
ParticipantScore[ParticipantScore<50]
ParticipantScore[ParticipantScore<50]<-40

ParticipantScore[-2,]
ParticipantScore[-2,c(-1,-3)]

m2<-ParticipantScore[-2,]
print(m2)

m3<-ParticipantScore[,-4]
print(m3)

ParticipantScore[ParticipantScore<50]#Appraisal Data for 4 quarters for 3 years
data<-c(1,3,2,3,4,4,4,4,1,4,2,3)

appData<-matrix(data,nrow=3,ncol=4,byrow = TRUE,
                dimnames=list(
                  c("2016","2017","2018"),
                  c("Q1","Q2","Q3","Q4")
                ))

print(appData)

appData["2017",]
appData[,"Q2"]
appData["2017",c("Q2","Q4")]<-3
print(appData)

appData[appData==4]<-3
print(appData)

salesMatrix<-matrix(401:424,nrow=2,
                    dimnames=list(c("2017","2018"),month.abb)
                    )

print(salesMatrix)


salesMatrix<-matrix(401:431,nrow=2)

print(salesMatrix)

SalesMatrix<-matrix(401:424,nrow=2,dimnames=list(c("2017","2018"),month.abb)
                    )

#cbind and Rbind
scores<-c(23,89,90,45,12,56,34,80,20,77,39,91,66,48,30)
ParticipantScore<-matrix(scores,nrow=3,ncol=5,byrow=TRUE)
print(ParticipantScore)


rownames1<-c("Ram","Sita","Ravan")
colnames1<-c("DevOps","Cloud","Python","Spring","Java")

dimnames(ParticipantScore)<-list(rownames1,colnames1)

print(ParticipantScore)

Krish<-c(70,70,80,90,45)

#Append a row use rbind
ParticipantScore<-rbind(ParticipantScore,Krish)
print(ParticipantScore)

#Test is conducted in 2 other modules
test<-matrix(c(45,34,67,89,23,10,80,67),
             nrow=4,
             dimnames=list(c(),c("Angular","AWS")))
print(test)

#Append a column use cbind                                 
ParticipantScore<-cbind(ParticipantScore,test)
print(ParticipantScore)

t(ParticipantScore)
                      

m1<-matrix(1:10,nrow=5)
              
print(m1)    

m2<-matrix(16:30,nrow=5)
                                    
print(m2)  

cbind(m1,m2)
                                    
rbind(m1,m2)                                   


#Matrix Addition

m1<-matrix(1:9,nrow=3)
m2<-matrix(1:9,nrow=3)

print(m1);print(m2)
m1+m2
m1-m2
m1*m2
m1/m2

m1<-matrix((1:9),nrow=3)
m2<-matrix((1:9),nrow=3)
print(m1);print(m2) 




                                    
                                    
                                    

