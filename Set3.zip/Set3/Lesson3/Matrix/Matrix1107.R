# Matrix

# Take a data and put it in rows and columns

v1<-c(67,23,90,89,12,88,30,77,12,55,10,45)
# Store the elemenst of a vector in 3 rows and 4 columns

length(v1)

# By default the data is populated in columnlar manner
m1<-matrix(v1,nrow=3,ncol=4)
print(m1)

m2<-matrix(v1,nrow=3,ncol=4,byrow = TRUE)
print(m2)

m3<-matrix(1:10,nrow=2)
print(m3)

m3<-matrix(1:11,nrow=2)
print(m3)


#Matrix rows and columns can have names

# Store the marks of 3 participants in 4 courses

c1<-c(34,23,12)
c2<-c(10,20,30)
c3<-c(56,45,89)
c4<-c(77,30,90)

participantScore<-matrix(c(c1,c2,c3,c4),nrow=3,
                         dimnames = list(
                           c("Ram","Vishnu","Karan"),
                           c("Python","R","DevOps","Cloud")
                         )
                         )
print(participantScore)

#Store the quarterly rating for 3 years
appraisalData<-matrix(
         c(2,3,2,3,4,3,4,1,2,3,4,2),
         nrow=3,ncol=4,byrow=TRUE
)
dimnames(appraisalData)= list(
  c("2016","2017","2018"),
  c("Q1","Q2","Q3","Q4")
)

print(appraisalData)
dim(appraisalData)

#Accessing the elements of a matrix

appraisalData[1,3]
participantScore[2,2]

appraisalData["2016","Q1"]
participantScore["Ram","Cloud"]
participantScore[c("Ram","Vishnu"),"Python"]
participantScore[1:3,3]

# Get me all the ratings of 2017

appraisalData[2,] # 2nd row

appraisalData["2016",]

#Get me all the scores in R progr

participantScore[,"R"]

participantScore[,c("R","Python","DevOps")]


participantScore[c("Ram","Vishnu"),c("R","Python")]

# Change the Q3, 2018 rating to 1
appraisalData["2018","Q3"]<-1
print(appraisalData)

appraisalData[appraisalData==4]<-1

print(appraisalData)

appraisalData[-2,]

appraisalData[-2,-3]

# Adding rows and columns to a matrix
sales<-matrix(
  c(10,20,30,55,44,33,66,88,40,50),
  nrow=5,
  dimnames = list(month.abb[1:5],c("A","B"))
)

print(sales)

# Append the June sales
June<-c(77,90)

sales<-rbind(sales,June)
print(sales)

m2<-matrix(c(70,20,10,15),ncol=2,dimnames=list(c("July","Aug"),
                          c("A","B"))
             )

print(sales)
print(m2)

#Append the rows of m2 to sales
sales<-rbind(sales,m2)
print(sales)

#cbind to append columns
C<-c(11,22,33,44,55,66,77,88)
sales<-cbind(sales,C)
print(sales)

t(sales)


m1<-matrix(c(3,7,8,9),nrow=2)
m2<-matrix(c(4,5,3,2),nrow=2)

# Non recycle rule
print(m1);print(m2)
m1+m2
m1-m2
m1*m2
m1/m2














