#Matrix- 2 dimensional DS

#Data to be populated in matrix
rScores<-c(56,67,34,78)
pythonScores<-c(89,90,23,12)
mlScores<-c(55,66,77,88)

#Store the scores of 4 employees in 3 trainings in a matrix
# 4 employees - row
# 3 trainings - columns
#4*3 matrix

#Row names and col names
empnames<-c("Sam","Nelson","Niel","Allen")
coursenames<-c("RScores","PythonScores","MLScores")


empScores<-matrix(
  c(rScores,pythonScores,mlScores),
  nrow = 4,
  ncol=3,
  dimnames = list(empnames,coursenames)
)

print(empScores)


m1<-matrix(1:20,nrow=5,ncol=4,byrow=TRUE)
print(m1)

m2<-matrix(1:20,nrow=5,ncol=4)
print(m2)

#Appraisal Data
# 4 quarters for 3 years 

appData<-matrix(
          c(1,3,2,3,3,4,3,2,1,3,4,2),
          nrow=3,
          dimnames=list(
            2015:2017,
            c("Q1","Q2","Q3","Q4")
          )
)

print(appData)


#Accessing a matrix

#Numeric index or Character index

empScores[2,3]
empScores[1,2]

#Access the 1st row
empScores[1,]

#Access the 3rd column
empScores[,3]

#Access the 1st and 2nd row
empScores[c(1,2),]
empScores[c(2,4),]

#Access the 2nd and 3rd column
empScores[,c(2,3)]

#Access the 1st and 3rd row and 2nd and 3rd column

empScores[c(1,3),c(2,3)]

#Get me Allen's score
empScores["Allen",]

#Get me the Python score of sam
empScores["Sam","PythonScores"]

#Get me the Python score of sam and Niel
empScores[c("Sam","Niel"),"PythonScores"]



#Get me the Python and ML score of sam and Niel
empScores[c("Sam","Niel"),c("PythonScores","MLScores")]


#Get me Allen's score
allenScore<-empScores["Allen",]
is.vector(allenScore)


appData["2017",]
appData[,"Q4"]

appData[1:2,2:4]


rownames(appData)

colnames(appData)

rownames(empScores)[2]
colnames(empScores)[3]

m3<-matrix(1:20,nrow=6,byrow=TRUE) #Recycle rule
print(m3)


c1<-colnames(empScores)
which(grepl("Python",c1))

which(grepl("Python",colnames(empScores)))


#rbind and cbind 
#rbind - adding a row(s) - No of columns shld be the same

print(empScores)

Wilson<-c(50,60,70)
Steve<-c(44,33,22)

empScores<-rbind(empScores,Wilson,Steve)
print(empScores)

#Cbind - bind a column(s) - No of rows should be the same
DevOps<-c(10,10,20,30,40,50)
empScores<-cbind(empScores,DevOps)
print(empScores)

Cloud<-c(10,30,40,50) #- No of rows =4
empScores<-cbind(empScores,Cloud)
print(empScores)

t(empScores)


m1<-matrix(c(2,4,3,5,6,8),nrow=2)
m2<-matrix(c(10,9,6,7,1,4),nrow=2)
print(m1)
print(m2)

m3<-rbind(m1,m2)
print(m3)

m4<-cbind(m1,m2)
print(m4)

m1+m2
m1-m2
m1*m2
m1/m2














