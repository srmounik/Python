# Matrix - 2D - Rows and columns and homogeneous
# data that should be populated in matrix, no of rows and no of cols
d1<-c(45,23,89,67,90,56,12,76)
m1<-matrix(d1,nrow=4,ncol=2) # column wise manner
print(m1)

m2<-matrix(d1,nrow=4,ncol=2,byrow = TRUE) # column wise manner
print(m2)

m3<-matrix(d1,nrow=4) # column wise manner
print(m3)

# Names for the rows and columns of a matrix:

rnames<-c("Allen","Sam","Tom","Emma")
cnames<-c("DevOps","AWS")

scores<-matrix(
            d1,
            nrow=4,
            ncol=2,
            byrow = TRUE,
            dimnames = list(rnames,cnames)
        )

print(scores)


salesA<-seq(24,46,by = 2)
salesB<-seq(20,55,by = 3)
salesC<-seq(30,65,by = 3)

salesMatrix<-matrix(
  c(salesA,salesB,salesC),
  nrow=12,
  dimnames=list(month.abb,c("Salesman A","Salesman B","Salesman C"))
)

print(salesMatrix)

m1<-matrix(1:50,nrow=5)
print(m1)

#Accessing a matrix
m1[4,8]
m1[3,10]
#Find the sales by B in June
salesMatrix["Jun","Salesman B"]

# Access entire row 
m1[2,]
# Access entire column
m1[,5]

# Access multiple elments
m1[c(1,3,5),]
m1[c(1,3,5),c(2,5,10)]

# Get me the sales made in Mar,July and OCt
salesMatrix[c("Mar","Jul","Oct"),]
salesMatrix[c(3,7,10),]

# Get me the sales made in Mar,July and OCt by Salesman A and C

salesMatrix[c("Mar","Jul","Oct"),c("Salesman A","Salesman C")]


mat1<-matrix(1:12,nrow=3)
mat2<-matrix(21:32,nrow=3)

mat1+mat2
mat1-mat2
mat1*mat2
mat1/mat2

mat3<-matrix(1:6,nrow=3)
mat1+mat3

print(mat1)
t(mat1)

appraisalData<-c(2,3,2,3,1,2,3,2,2,1,2,1)
rn<-c("2016","2017","2018")
cn<-c("Q1","Q2","Q3","Q4")

appData<-matrix(appraisalData,nrow=3,dimnames=list(rn,cn))
print(appData)

# Add data for the year 2019
newdata<-matrix(c(1,2,1,2),nrow=1,dimnames = list(c(2019),cn))
print(newdata)

appData4<-rbind(appData,newdata)

# Add overall rating
overall<-matrix(c(3,2,2,1),nrow=4,dimnames=list(c(rn,"2019"),c("Overall")))
print(overall)

finalRating<-cbind(appData4,overall)

m4<-matrix(1:8,nrow=4)
m5<-matrix(1:16,nrow=8)

print(m4);print(m5)

cbind(m4,m5)


































