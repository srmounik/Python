# Matrix- 2 dimensional homogeneous DS

# Matrix has rows and columns 

d1<-c(12,34,54,98,10,34,77,88,99,22)
length(d1)

print(d1)

# put d1 in a matrix with 2 rows and 5 columns
#Data is populated in a columnlar manner

m1<-matrix(d1,nrow=2,ncol=5)
print(m1)

m2<-matrix(d1,nrow=2,ncol=5,byrow = TRUE)
print(m2)

m3<-matrix(1:24,nrow=6,byrow=TRUE)
print(m3)

m4<-matrix(1:24,ncol=6,byrow=TRUE)
print(m4)

m4<-matrix(1:27,ncol=6,byrow=TRUE)
print(m4)

marks<-c(12,92,33,44,55,91,87,16,43,100,67,72)

#No names for rows and cols
markMat<-matrix(marks,ncol=4)
print(markMat)

#Names for rows and cols
rNames<-c("Ram","Lakshman","Bharath")
cNames<-c('Python','DevOps','Cloud','Angular')

markMat<-matrix(marks,ncol=4,byrow=TRUE,
                dimnames=list(rNames,cNames))
print(markMat)


markMat<-matrix(marks,ncol=4,byrow=TRUE,
                dimnames=list(
                  c("Ram","Lakshman","Bharath"),
                  c('Python','DevOps','Cloud','Angular')
                ))
print(markMat)


#Accessing a matrix

markMat[1,2]
markMat[3,4]

row.names(markMat)
colnames(markMat)

markMat[2,c(1,2)]

markMat[c(1,2),c(2,4)]

#Access the 3rd row

markMat[3,]

#Access the 2nd column
markMat[,2]
markMat[,2:4]

markMat[markMat>60]

print(markMat)

which(markMat>60,arr.ind = TRUE)

#Named Matrix

markMat["Ram","DevOps"]

markMat[c("Ram","Bharath"),c("DevOps","Python")]

markMat[c("Ram","Bharath"),]

markMat["Ram","DevOps"]<-10

print(markMat)

#How to add a row to a matrix - rbind

Sita<-c(50,60,70,80)

markMat<-rbind(markMat,Sita)

print(markMat)

#How to add a column to a matrix - cbind

RProg<-c(22,33,44,55)
markMat<-cbind(markMat,RProg)
print(markMat)



#Create a named matrix

prod<-matrix(c(27,45,2,3,89,100),
             nrow=2,
             dimnames=list(
               c("LCD","Laptop"),
               c("Price","TaxRate","Qty")
             ))

print(prod)

prod2<-matrix(c(55,92,1,2,10,20),
             nrow=2,
             dimnames=list(
               c("Book","Garments"),
               c("Price","TaxRate","Qty")
             ))
print(prod2)


#For rbind no of cols should be the same
prod<-rbind(prod,prod2)

#Matrix

m1<-matrix(1:12,ncol=4)
print(m1)


m2<-matrix(10:17,ncol=4)
print(m2)

m1<-rbind(m1,m2)
print(m1)

m3<-matrix(31:40,nrow=5)
print(m3)
m1<-cbind(m1,m3)
print(m1)

m1[m1[,1]==10,]

#Index of elements where value is >10
which(m1>10,arr.ind = TRUE)

m1[which(m1>10)]

print(markMat)
markMat["Bharath","RProg"]<-NA

CProg<-c(80,NA,67,100)
markMat<-cbind(markMat,CProg)











