desig<-c("SE","SSE","TL","Mgr","SE","SSE","SSE","Mgr",
         "SE","SE","SSE","TL","SSE","SSE","TL","Mgr",
         "SE","SSE","TL","SE","SE","SE","SE","SSE")

# Categorical Data
# Factor is used for vectors with categorical data

is.factor(desig)
is.vector(desig)

# Create a factor for desig
f1<-factor(desig)
print(f1)
str(f1)

#1) It will find out the unique values - SE, SSE, TL, Mgr
#2) Sort the values and use them as levels - Mgr,SE,SSE,TL
#3) Assign numbers to levels - 1-Mgr,2-SE,3-SSE,4-TL
#4) Internally it will store the data using the numbers
#5) c("SE","SSE","TL","Mgr","SE","SSE","SSE","Mgr",
# "SE","SE","SSE","TL","SSE","SSE","TL","Mgr",
# "SE","SSE","TL","SE","SE","SE","SE","SSE") will be stored as
# c(2,3,4,1,2,3,3,1...)



# In a factor you cannot change or insert a value which is not in the level
print(f1)
#Change f1[1] to SSE
f1[1]<-"SSE"
print(f1)
#Change f1[6] to TL
f1[6]<-"TL"
print(f1)
#Change f1[4] to VP - Incorrect
f1[4]<-"VP"
print(f1)

# Add VP as a level
print(levels(f1))
levels(f1)<-c(levels(f1),"VP")
print(levels(f1))

f1[4]<-"VP"
print(f1)


locs<-c("Delhi","Chennai","Mumbai","Delhi","Chennai","Mumbai","Delhi","Chennai","Mumbai",
        "Delhi","Chennai","Mumbai","Delhi","Chennai","Mumbai","Delhi","Chennai","Mumbai")
# Later Kolkatta and Pune can be added
factorLocs<-factor(locs,levels=c("Kolkatta", "Delhi","Chennai","Mumbai","Pune"))
print(factorLocs)
factorLocs[1]<-"Pune"
print(factorLocs)

directions<-factor(,levels=c("North","South","West"))
print(directions)
directions[1]<-"West"
print(directions)


#Table is tabulation
print(f1)
table(f1)


