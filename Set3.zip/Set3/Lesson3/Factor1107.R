#Categorical data - the vector will have only few values repeated
desig<-c("SE","TL","Mgr","SSE","SSE","SE",
         "TL","Mgr","Mgr","SE","SSE","TL","TL",
         "Mgr","TL","SSE","SE","TL","SE")

is.factor(desig)

fdesig<-factor(desig)
is.factor(fdesig)

# 1- Takes the unique values from the vector - SE,TL,Mgr,SSE
# 2- Sort the unique values - Mgr,SE,SSE,TL
# 3 - Give numbers for the sorted values - 1- Mgr,2- SE,3-SSE,4-TL
# 4 - These are called as Levels (1- Mgr,2- SE,3-SSE,4-TL)
# 5 - The values in the factor can take only these 4 levels
# 6 - The data is taken ("SE","TL","Mgr","SSE","SSE","SE"...) and insted of SE,SSE
# the level numbers are stored internally ...2,4,1,3,3,2...

str(fdesig)

print(fdesig)

fdesig[1]<-"SSE"

print(fdesig)

fdesig[2]<-"Mgr"

print(fdesig)

fdesig[3]<-"Director"

print(fdesig)

levels(fdesig)<-c(levels(fdesig),c("Director","VP"))

str(fdesig)

fdesig[3]<-"Director"

print(fdesig)



gender<-c("M","F","M","F","M","F","M","M",
          "M","F","M","F","M","F","M","M","M","F","M","F","M","F","M","M",
          "M","F","M","F","M","F","M","M")

fgender<-factor(gender,levels=c("M","F","T"))
print(fgender)
str(fgender)
fgender[1]<-"T"

#Table 
table(gender)

table(desig)

table(fdesig)

table(fgender)


