#Vector - one dimensional homogeneous collection of elements

#To create a vector - c()

salary<-c(34564,84567,12100,45789)#Vector having 4 elements [1:4]

ids<-6:20
typeof(ids)
class(ids)
str(ids)
print(ids)

empids<-seq(10,23)
print(empids)

status<-rep(8,20)
print(status)

v1<-c(1:3,seq(10,14),45,89,23,12,rep(5,3))
print(v1)

length(v1)


empNames<-c("Ram","Vishnu","Shiva","Krish","Sita","Ravan")
print(empNames)

stockData<-c(T,F,T,T,F,F,T,F,F)
print(stockData)

#In R everything is a vector
age<-10 # age is a vector having 1 element of type number

myV1<-c(16,"Hello",TRUE,677+3i)# R will convert everything to a same type
print(myV1)


myV2<-c(16,TRUE,677+3i)# R will convert everything to a same type
print(myV2)

myV2<-c(16,TRUE,665.89)# R will convert everything to a same type
print(myV2)

myV2<-c(16,TRUE,333)# R will convert everything to a same type
print(myV2)

sal<-34555 # Vector with 1 value

v1<-10:-19
print(v1)

#Create the vector then give names
marks<-c(10,34,56,77,23,53,98)
print(marks)

names(marks)<-c("Ram","Shiv","Krish","Manu","Maya","Sita","Ravan")
print(marks)

# Give names when the vector is created
prod<-c("TV"=78789,"Book"=56457,"Shoes"=4565,"iPhone"=87847)
print(prod)


n1<-c(3,9)
n2<-c(10,4)
rep(n1,n2)

#Accessing a vector


projIds<-c(56,23,68,90,24,67,100,457,322,87,22,934,727,392,10,80)
#numeric index
projIds[1]
projIds[5]
projIds[3:8]
projIds[c(5,7,8,10)]
projIds[c(1:3,13:15)]
projIds[-1]
projIds[-c(2,4,6)]
projIds[c(-2,1)] # Not allowed

salary<-c(3456,2356,9090,2676,8989,6565,7090,1488)

salary[-3]
salary[c(T,T,F,F,F,F,T,T)]
salary[c(T,F)] # repeat T,F -> T,F,T,F,T,F,T,F
salary[c(T,F,T)] # repeat T,F,T -> T,F,T,   T,F,T,  T,F,T
salary[salary>5000]
salary[!salary>5000]

#Character Index - named Vectors
marks<-c(10,34,56,77,23,53,98)
print(marks)

names(marks)<-c("Ram","Shiv","Krish","Manu","Maya","Sita","Ravan")
print(marks)

# Give names when the vector is created
prod<-c("TV"=78789,"Book"=56457,"Shoes"=4565,"iPhone"=87847)
print(prod)

marks[1]
marks[marks>40]
marks["Manu"]
marks[c("Shiv","Maya","Krish")]

prod[c("Book","Shoes")]
prod[prod>50000]

marks[grepl("a",names(marks))]
marks[grepl("*a$",names(marks))]
marks[grepl("an",names(marks))]
marks[grepl("^M",names(marks))]
marks[grepl("^M%y",names(marks))]

# Modify the elemenst
print(marks)
marks[3]<-100
print(marks)

marks[marks<40]<-45
print(marks)

marks["Sita"]<-20
marks["Maya"]<-25
#Delete the elements
marks<-marks[-2]
print(marks)

sort(marks)
order(marks)
marks[order(marks)]
sort(marks,decreasing = TRUE)
sort(names(marks))
marks[sort(names(marks))]

marks[sort(names(marks),decreasing = TRUE)]

sum(marks)
min(marks)
max(marks)
range(marks)
which.min(marks)
which.max(marks)

v1<-c(2,NA,3,NA,4,5,6,NA)
sum(v1)
sum(v1,na.rm = TRUE)

min(v1,na.rm=TRUE)
max(v1,na.rm=TRUE)

v1[is.na(v1)]<-10
print(v1)


print(v1)
which(is.na(v1))
v1<-v1[-which(is.na(v1))]
print(v1)

v1<-c(5,6,7,8)
v1*4

v2<-c(10,14,12)

v3<-c(v1,v2)
print(v3)

v1+v2
v1-v2
v1*v2
v1/v2


oldEmps<-c("Ram","Shiv","Krish","Manu","Maya","Sita","Ravan")
newEmps<-c("Tina","Binu")

emps<-c(oldEmps,newEmps)



v1<-c(0,1,0,1)
v2<-c(1,0,0,0)

v1|v2
v1||v2

v1&v2
v1&&v2





