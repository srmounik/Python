mark<-89
name<-"Hema"
# Vector - 1 dimensional data structure

mark<-45 # 1 dimensional vector with 1 element ie. mark=[45]

# To create a vector - c()

marks<-c(30,90,67,45,23,88) # Numeric Vector containing 6 elements
typeof(marks)
length(marks)

employees<-c("Veena","Sonu","Tina","Manish","Ganesh","Tarun","Varun")

typeof(employees)
length(employees)

status<-c(T,F,T,T)
typeof(status)

empid<-c(101L,105L,899L,344L,877L)
typeof(empid)

patientId<-78:99
print(patientId)

bonus<-seq(1000,5000,by=200)
print(bonus)

lottery<-rep(5,10)
print(lottery)

scores<-c(23:25,seq(30,45,by=3),rep(50,2),89,12,14,60:63)
print(scores)

v1<-c("Hello",78.23,TRUE,8L)
print(v1)

v1<-c(78.23,TRUE,8L)
print(v1)

v1<-c(TRUE,8L)
print(v1)


# Elements in the vector can have names
salary<-c(45675,34446,90000,26677,12000)
print(salary)
names(salary)<-c("Anu","Karan","Simi","John","Laurel")
print(salary)

score<-c("Veena"=90,"Tina"=45,"Renu"=67,"Nina"=34,"Emma"=55)
print(score)


print(month.name)

print(month.abb)

rainfall<-c(23,34,54,43,22,10,55,66,77,85,90,50)
print(rainfall)
names(rainfall)<-month.abb
print(rainfall)

# Accessing the elements of a vector


scores<-c(23:25,seq(30,45,by=3),rep(50,2),89,12,14,60:63)
print(scores)

# Index starts at 1
# Numeric index
scores[1]
scores[8]
scores[2:5]
scores[c(3,7,9)]

scores[-1] # Give me all elements except 1st element
scores[-c(2:5)]
scores[-c(2,4,1,3,6,5,10,12)]
scores[c(3,-5)]

# Logical index
employees<-c("Veena","Sonu","Tina","Manish","Ganesh","Tarun","Varun")
print(employees)
employees[c(T,T,F,F,F,T,T)]
employees[c(T,F)]

# Character index - Only if the vector elements have names
rainfall<-c(23,34,54,43,22,10,55,66,77,85,90,50)
names(rainfall)<-month.abb
print(rainfall)
rainfall[1:6]
rainfall[c(T,T,F)]
rainfall["Aug"]
rainfall[c("Mar","Jun","Sep","Dec")]

# Logical access
rainfall[rainfall>50]
scores[scores>70]

#Order will return the index of elements in ascending order
order(rainfall)
order(rainfall,decreasing = TRUE)

rainfall[order(rainfall)]
rainfall[order(rainfall,decreasing = TRUE)]

employees[order(employees)]

# Make the rainfall of Jun as 100
rainfall["Jun"]<-100

print(rainfall)

print(scores)
scores[scores<50]<-66
print(scores)

scores<-scores[1:5]


# Functions on vectors

m1<-c(10,20,30,40)
m2<-c(55,67,12)
m3<-c(43,18)

m1<-c(m1,m2,m3)

emp1<-c("Anu","Karan","Simi","John")
newJoines<-c("Lalit","Parth")
emp1<-c(emp1,newJoines)
print(emp1)


print(m1)
min(m1)
max(m1)
sum(m1)
prod(m1)

min(rainfall)
sum(rainfall)
sort(rainfall)
sort(rainfall,decreasing = TRUE)

v1<-c(2,3,4,5)
v2<-c(6,1,0,8)
v1+v2
v1-v2
v1*v2
v1/v2

v1&v2
v1&&v2

v1<-c(2,3,4,5)
v2<-c(6,1) # v1+v2, v1 has 4 elements but v2 has only 2 elements 
# recycle v2 - 6,1,6,1

v1+v2

v1<-c(2,3,4,5,8,9,10)
v2<-c(6,1) # v1+v2, v1 has 7 elements but v2 has only 2 elements 
# recycle v2 - 6,1,6,1,6,1,6,1

v1+v2

v1<-c(2,3,4,5,NA,10,9,NA,NA,6)
min(v1,na.rm = TRUE)
max(v1,na.rm = TRUE)
sum(v1,na.rm = TRUE)
sum(v1)

which.min(m1)
which.max(m1)

range(v1,na.rm = TRUE)


