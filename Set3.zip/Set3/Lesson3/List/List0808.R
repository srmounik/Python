# List is a heterogenous 1 D data structure

empdata<-list(12,"Ram",234245,TRUE)
print(empdata)

str(empdata)

empdata<-list("empid"=12,"empName"="Ram","salary"=34534,"isContract"=FALSE)
print(empdata)
str(empdata)

appdata1<-matrix(c(1,3,3,4,2,2,3,3),ncol=4,
                 dimnames = list(
                   c("2016","2017"),
                   c("Q1","Q2","Q3","Q4")
                 ))

print(appdata1)

skills<-c("DevOps","Python","R","Cloud")

crticalRes<-list(
   "empid"=90,
   "name"="Yuvan",
   "salary"=67676,
   "techSkill"=skills,
   "rating"=appdata1
)

print(crticalRes)

str(crticalRes)

r1<-c("Row1","Row2")
c1<-c("C1","C2","C3","C4")
t1<-c("Tray1","Tray2","Tray3")
b1<-c("Box1","Box2")

eggs<-array(1:48,dim = c(2,4,3,2),
            dimnames = list(r1,c1,t1,b1))
print(eggs)


crticalRes[["eggShelf"]]<-eggs

#List
crticalRes<-list(
  "empid"=90,
  "name"="Yuvan",
  "salary"=67676,
  "isContract"=FALSE,
  "projIds"=c(109,34,234,89,675,40),
  "techSkill"=skills,
  "rating"=appdata1
)
print(crticalRes)

#Access a list - [], [[]], $

#[] - Box number 4
crticalRes[4]
crticalRes[c(4,5,2)] # Sub List - get me the Box numbers 4,5 and 2

#[[]] - Content of a particular box
#[[]] - Use numeric index or named index
crticalRes[[4]] # Open the box #4 and get me what is inside it
crticalRes[[c(4,5)]] 

# Change the Q3 2016 rating to 1

crticalRes[7][1,3]<-1

crticalRes[[7]][1,3]<-1

crticalRes[["name"]]

crticalRes[["rating"]]

#$ - same as [[]], but it can be used only for named access

crticalRes$rating

crticalRes$techSkill

crticalRes$techSkill[1:3]

crticalRes$1

crticalRes[c(T,F,T)]

str(crticalRes)

crticalRes[[4]]<-NULL

str(crticalRes)




