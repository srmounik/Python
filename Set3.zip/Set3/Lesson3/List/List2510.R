# List is heterogeneous 1 Dimensional DS

empData<-list(101L,"Suraj",78788.56,TRUE)
print(empData)

emp<-list("EmpId"=101L,"Name"="Tarun","Salary"=73485.45,"isContract"=FALSE)
print(emp)

# A list can contain a vector or matrix as its element
Emp1<-matrix(c(1,1,3,2,3,4,3,2,1,3,2,4),
             ncol=4,
             dimnames=list(
               c("2016","2017","2018"),
               c("Q1","Q2","Q3","Q4")
             ))

emp<-list("EmpId"=101L,
          "Name"="Tarun",
          "Salary"=73485.45,
          "isContract"=FALSE,
          "skills"=c("Java","Cloud","UX","Data Science"),
          "rating"=Emp1,
          "projects"=c(234,788,900))
print(emp)

str(emp)

# Access the elements of a list - [], [[]], $

# Instruction 1- Get me the bag # 2, 5 and 7-[] - Sub list
emp[c(2,5,7)]

emp[3]


# Instruction 2- Get me the contents of the bag #3 - [[]]

emp[[3]]

emp[["projects"]]

# $ - same as [[]], but u cant use numeric index with $

emp$3
emp$projects
emp$EmpId
emp$rating

# Change the Q3 2018 rating to 4

emp["rating"]["2018","Q3"]
emp[["rating"]]["2018","Q3"]<-4
emp$rating["2018","Q3"]

emp["Location"]<-"Chennai"
print(emp)

emp["Salary"]<-NULL
print(emp)














