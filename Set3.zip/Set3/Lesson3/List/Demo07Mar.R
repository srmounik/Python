# List -> can store elements of differnt type
appData<-c(1,3,2,3,1,1,1,1,2,3,4,2)
table(appData)

rownames<-c("2016","2017","2018")
colnames<-c("Q1","Q2","Q3","Q4")
l1<-list(rownames,colnames)

appMatrix<-matrix(appData,nrow=3,
                  dimnames =l1)
print(appMatrix)


empData<-list("empid"=101L,
              "name"="Suraj",
              "salary"=90765.45,
              "location"="Chennai",
              "isContract"=FALSE,
              "ratings"=appMatrix,
              "skills"=c("R","DevOps","Cloud"),
              "project"=c(108,345,234,900))
print(empData)


accountData<-list(105,"Ram",45345,TRUE,c(34,23,56,90))
print(accountData)

accountData<-list("accId"=105,"CustName"="Ram",
                  "Balance"=45345,
                  "isActive"=TRUE,
                  "interst"=c(34,23,56,90))
print(accountData)


# There are three ways in which you can access a list
print(empData) # 8 boxes

#1->[] -> Get me the box(es)
empData[c(3,5,7)] # Get me the box number 3,5 and 7
empData[c("salary","location")] # get me box with name salary and location

#2-> [[]] -> Open one box and get the content
empData[[3]] #Open Box number 3 and get me the content
empData[["ratings"]] #Open the box with name rating and get me the content
#Invalid - empData[[c(3,5)]]

#3 - $ -> same as [[]] but it cannot be used with numeric index
#Invalid - empData$3
empData$location
empData$ratings

# Change the Q4 2018 rating to 4

empData["ratings"][3,4]<-4 # [] It gets us the box, it is not opened 

empData[["ratings"]][3,4]<-4 

str(empData)

typeof(empData)
typeof(empData[1])
typeof(empData[[1]])

empData["desig"]<-"Manager"
print(empData)

empData["isContract"]<-NULL
print(empData)

data<-list(10,20,30,40,50)
data[[c(1,4)]]
data[c(1,4)]
data$1
data[c(10,40)]
data[[4]]

