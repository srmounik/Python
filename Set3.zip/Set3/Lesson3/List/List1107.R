empData<-list(101,"Ram","Mgr",9090.90,TRUE)
print(empData)

str(empData)

product<-list("pid"=676L,"PName"="Pen","price"=30,
              "desc"="Gel Pen","inStock"=TRUE)
print(product)

# List can have a vector or a matrix as its element

emp<-list(
     "empId"=345L,"empName"="Tarun","Salary"=46738.90,
     "isContract"=FALSE,
     "Skills"=c("DevOps","JavaFSD","Python"),
     "ProjectId"=c(108,345,899,200),
     "ratings"=matrix(c(1,2,3,2,1,1,1,1),
                      ncol=4,
                      dimnames = list(
                        c("2017","2018"),
                        c("Q1","Q2","Q3","Q4")
                      ))
)
print(emp)
str(emp)

sink("File1.txt")
print("----------Employee Data---------")
print(emp)
print("--------------------------------")
sink()

#Accessing the elements

# 3 ways - [], [[]] and $

# Get me the box #2 and #4 -[] 

emp[c(2,4)]
emp[1]
emp[6]
emp[7]
emp["ratings"]


#Change the Q3 2018 rating to 4
emp["ratings"]["2018","Q3"]<-4

emp[["ratings"]]["2018","Q3"]<-4

emp$ratings["2018","Q2"]<-4




# Get me the content in Box #3 - [[]] - index and name
emp[[3]]
emp[[7]]
emp[["ratings"]]
emp[["Skills"]]

# $ is same as [[]], but it can be used only with character

emp$ratings
emp$Salary

emp[["Location"]]<-"Chennai"
print(emp)

emp[["isContract"]]<-NULL
print(emp)

emp[["projectId"]]<-c(100,200,300)


emp["Salary"]<-78787




