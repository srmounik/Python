#List - heterogenous Data Structure

#One D, which can store data of differnt type
product<-list(89L,"LCD",8989.67,TRUE)
product[[3]]

#In a list u can store a Vector or a matrix as an element

appData<-matrix(
  c(1,3,2,3,3,4,3,2,1,3,4,2),
  nrow=3,
  dimnames=list(
    2015:2017,
    c("Q1","Q2","Q3","Q4")
  )
)

# 6 boxes, empid -Integer, name-Char,salary-double
# isPer..-boolean, skills-Vector, rating-matrix

empData<-list("empid"=101L,
              "empName"="Ram",
              "salary"=45767.78,
              "isPermament"=TRUE,
              "skills"=c("Analytics","Cloud","AI","Python"),
              "rating"=appData
)

str(empData)

print(empData)

#Accessing the elements of a list

# [], [[]], $

#[] - Get me the box numbers/names - sublist

empData[c(3,5)] #Get me the box #3 and #5
empData["empName"] #Get me the box with name EmpName
 
#[[]] - Get the content of 1 BOX  numbers/name

empData[[3]]

empData[[5]]

#Invalid - empData[[c(3,5)]]

empData[["empName"]]

#$ - Get the content of 1 BOX  name
empData$salary
empData$rating

#Get the Q4 rating of 2017
empData$rating[3,4]
empData$rating["2017","Q4"]
empData[["rating"]][2,1]
empData[[6]]["2015","Q2"]

#Invalid- empData[6][2,1]

#Change the Q2 2016 rating to 4

empData$rating["2016","Q2"]<-4
empData$rating["2016","Q2"]


#Invalid - empData$1

empData[c(T,F,F,T,T,F)]

empData[["ProjectId"]]<-c(101,456,898)

print(empData)

empData$isPermament<-NULL
print(empData)











