l1<-list("names"=c("Anu","Tina","Kate"),
         "ids"=c(109,56,345,6789,909))
str(l1)


employee<-list("empid"=101L,
               "name"="Allen",
               "salary"=67678.56,
               "location"="Chennai",
               "skills"=c("Java","R","Cloud"))

m1<-matrix(c(3,2,3,4,3,2,1,3,3,4,2,4),
           nrow=3,
           dimnames=list(
             c("2016","2017","2018"),
             c("Q1","Q2","Q3","Q4")
           )
           )
print(m1)
str(employee)

# Add new elements to the list
employee[["appraisalData"]]<-m1
print(employee)

# Employee is a list which contains 6 boxes

#Accessing the elements - [], [[]],$

#[] - Get me the box 2,5,6 - SubList is returned
employee[c(2,5,6)]

#[[]] - Get the content from 1 box
employee[[6]]

#Difference [] and [[]]
#Change the Q3 2017 rating of the employee to 1
employee[6][2,3]<-1
employee[[6]][2,3]<-1

#$ is similar to [[]], but
# [[]] - can be used with numeric or character index
employee[[4]]
employee[["location"]]
#$ - can be used only with character index
employee$salary

employee$appraisalData[1,1]<-4























