desig<-c("SE","TL","Mgr","SSE","SSE","SE","TL","Mgr",
         "Mgr","SE","SSE","TL","TL")
is.vector(desig)
is.factor(desig)

fdesig<-factor(desig)
is.vector(table(fdesig))
# Find the unique values in the vector - SE,TL,Mgr,SSE
# Sort the values - Mgr,SE,SSE,TL
# Give numbers for the sorted values  1-mgr,2-SE,3-SSE,4-TL
# Make these as levels - Levels - Mgr,SE,SSE,TL
# The original data is ("SE","TL","Mgr","SSE","SSE",...)
# Internall instead of the Levels it will store the level numbers
# ("SE","TL","Mgr","SSE","SSE",...) = (2,4,1,3,3,...)

print(fdesig)
str(fdesig)

#fdesig has 4 levels - Mgr,SE,SSE,TL
print(fdesig)
fdesig[1]<-"SSE" # Allowed as SSE is a valid level
print(fdesig)
fdesig[3]<-"VP" # Not Allowed as VP is not a valid level
print(fdesig)

levels(fdesig)<-c(levels(fdesig),"VP")

fdesig[3]<-"VP" #  Allowed as VP is  a valid level
print(fdesig)

locs<-c("Pune","Mumbai","Chennai","Pune","Mumbai","Chennai",
        "Pune","Mumbai","Chennai","Pune","Pune","Chennai")

fLocs<-factor(locs,levels=c("Mumbai","Bangalore","Chennai","Pune","Noida"))
print(fLocs)
str(fLocs)

table(fLocs)







