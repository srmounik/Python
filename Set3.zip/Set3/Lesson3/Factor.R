desig<-c("SE","SSE","Mgr","TL","TL","SSE","SE","Mgr","SSE","SSE","SE","TL")

#Unique values - Levels- Mgr-1,SE-2,SSE-3,TL-4

# desig =2,3,1,4,4,3,2,1,3,3,2,4
is.factor(desig)

fDesig<-factor(desig)
is.factor(fDesig)
print(fDesig)
str(fDesig)

fDesig[2]<-"VP" # Error- coz VP is not a valid Level

fDesig[4]<-"Mgr" # Allowed- Mgr is a valid Level

levels(fDesig)
levels(fDesig)<-c(levels(fDesig),"VP")
levels(fDesig)

#Table - Tabularising data by counting it
t1<-table(fDesig)
print(t1)

month.name[]

sample(month.name)




