desig<-c("SE","SSE","SE","SSE","TL",
         "Mgr","SSE","SSE","Mgr","TL",
         "SE","SSE","TL","Mgr","SE","SSE","SE","SSE","TL",
         "Mgr","TL","SSE")

is.vector(desig)
is.factor(desig)

print(desig)

fd<-factor(desig)
# 1) Count the unique values in the vector - "SE", "SSE","TL","Mgr"
# 2) Sort the values -"Mgr","SE", "SSE","TL"
# 3) Make these sorted values as levels - Levels- "Mgr","SE", "SSE","TL"
# 4) Give unique numbers for Levels :
#     1- "Mgr",2-"SE", 3-"SSE",4-"TL"
# 5) Internally in the factor store the level number insted of value
# ie. "SE","SSE","SE","SSE","TL"... insted 2,3,2,3,4...

print(fd)
str(fd)

# The elements in the factor can take only 4 values ie. Level values
fd[2]<-"TL" # Check if "TL" is a valid Level
print(fd)

fd[6]<-"Director" # Check if "Director" is a valid Level
print(fd)

fd[is.na(fd)]<-"Mgr"
print(fd)

levels(fd)<-c(levels(fd),"Director","VP")
fd[6]<-"Director" # Check if "Director" is a valid Level
print(fd)

fdesig<-factor(desig, levels=c("SE","SSE","TL","Mgr","ASE","VP","Drctr"))
print(fdesig)
fdesig[1]<-"VP"
fdesig[fdesig=="Mgr"]<-"Drctr"
print(fdesig)

table(desig)







