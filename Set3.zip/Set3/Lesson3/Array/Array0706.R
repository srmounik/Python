eggs<-array(
     1:48,
     dim = c(2,4,3,2),
     dimnames=list(
       c("Row1","Row2"),
       c("C1","C2","C3","C4"),
       c("T1","T2","T3"),
       c("B1","B2")
     )
)

print(eggs)

eggs[2,3,1,2]

eggs[,,"T2","B1"]

eggs[,,,"B2"]

eggs[,,"T1",]


# I want to store appraisal Data for 3 employees for 2 years for 4 quarters
# row=2 years, col=4 Q1, emp=3 employees

emp1<-c(1,1,1,1,1,1,1,1)
emp2<-c(2,3,2,3,2,3,2,3)
emp3<-c(2,4,1,4,2,3,1,1)

year<-c(2016,2017)
quart<- c("Q1","Q2","Q3","Q4")
emps<-c("Ram","Sita","Ravan")

empRatings<-array(
    c(emp1,emp2,emp3),
    dim=c(2,4,3),
    dimnames=list(year,quart,emps)
)

print(empRatings)

empRatings[,,"Sita"]

empRatings[,"Q2",]

empRatings["2017",c("Q2","Q4"),]

empRatings[empRatings==1]<-4

print(empRatings)

which(empRatings==2,arr.ind = TRUE)





