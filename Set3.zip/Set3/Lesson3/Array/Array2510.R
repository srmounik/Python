# Array is a multi dimension Data structure

eggs<-array(1:24,dim = c(2,4,3),
            dimnames = list(
              c("R1","R2"),
              c("C1","C2","C3","C4"),
              c("Tray1","Tray2","Tray3")
            ))

print(eggs)


eggs<-array(1:48,dim = c(2,4,3,2),
            dimnames = list(
              c("R1","R2"),
              c("C1","C2","C3","C4"),
              c("Tray1","Tray2","Tray3"),
              c("Box A","Box B")
            ))

print(eggs)

eggs[1,3,2,2]
eggs["R1",,"Tray3","Box B"]

eggs[,,"Tray2",]

eggs[,2,,1]


# Array example

Emp1<-matrix(c(1,1,3,2,3,4,3,2,1,3,2,4),
              ncol=4,
              dimnames=list(
                c("2016","2017","2018"),
                c("Q1","Q2","Q3","Q4")
              ))
print(Emp1)

# Store the appraisal data for 3 employees

AppArray<-array(
  c(1,1,3,2,3,4,3,2,1,3,2,4,rep(3,12),rep(1:4,3)),
  dim=c(3,4,3),
  dimnames=list(
    c("2016","2017","2018"),
    c("Q1","Q2","Q3","Q4"),
    c("Employee A","Employee B","Employee C")
  )
  
)

print(AppArray)

AppArray[,"Q4",]

AppArray[AppArray==1]<-5










