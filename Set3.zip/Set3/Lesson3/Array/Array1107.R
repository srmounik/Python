#Array - Multidimensional DS > 2 D

eggs<-array(1:24,dim = c(2,4,3))
print(eggs)
eggsinBox<-array(1:48,dim = c(2,4,3,2))
print(eggsinBox)

eggsinBox[2,3,2,1]
eggsinBox[,,3,1]
eggsinBox[,,,1]

dimnames(eggsinBox)<-list(
  c("R1","R2"),
  c("C1","C2","C3","C4"),
  c("T1","T2","T3"),
  c("B1","B2")
)

eggsinBox["R1",,"T2",]

# Store the appraisal data for 3 employees
app1<-c(1,1,1,1,1,1,1,1,1,1,1,1)
app2<-c(2,3,3,3,3,3,2,2,2,3,2,3)
app3<-c(3,2,1,1,2,3,3,2,3,2,3,2)

appArray<-array(c(app1,app2,app3),
                dim = c(3,4,3),
                dimnames= list(
                  c("2016","2017","2018"),
                  c("Q1","Q2","Q3","Q4"),
                  c("Ram","Vishnu","Shiva")
                )
)

print(appArray)

# Get me al"l ratings of Shiva
appArray[,,"Shiva"]

# Get me all Q2 ratings
appArray[,"Q2",]

#Change the 2018 rating of "Ram" to 2
appArray["2018",,"Ram"]<-2

print(appArray)

appArray[appArray==3]<-1
print(appArray)
















