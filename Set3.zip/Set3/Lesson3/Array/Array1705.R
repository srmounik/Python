#Creating an array

eggs<-array(1:48,dim=c(2,4,3,2),
            dimnames = list(1:2,1:4,c("T1","T2","T3"),c("Box1","Box2"))
              )

print(eggs)

eggs[2,3,1,2]

eggs[2,,1,2]

eggs[,,2,2]

eggs[,,,1]

eggs[1,1,1,1]<-100


#Store appraisal Data for 3 employees

# 3 years and 4 quarters

# row= 3 years, col= 4 Quarters, 3rd dimension = no of employees =3

data<-c(1,3,2,3,4,4,4,4,1,4,2,3,
        2,2,2,2,2,2,2,2,2,2,2,2,
        rep(3,12))

appData<-array(data,dim=c(3,4,3),
               dimnames = list(
                 c("2016","2017","2018"),
                 c("Q1","Q2","Q3","Q4"),
                 c("Ram","Vishnu","Shiv")
               ))

print(appData)

#All year all employees Q2 appraisal Data
appData[,"Q2",]

appData[,,c("Ram","Shiv")]

appData["2016","Q3",]

appData["2017",,"Shiv"]<-1


















