eggs<-1:24

rownames<-c("Row1","Row2")

colnames<-c("Col1","Col2","Col3","Col4")

traynames<-c("Tray1","Tray2","Tray3")

myEggRack<-array(eggs,dim = c(2,4,3),dimnames=list(rownames,colnames,traynames))

print(myEggRack)

eggsInHand<-1:48

boxnames<-c("Box1","Box2")

myEggBoxes<-array(eggsInHand,dim=c(2,4,3,2),dimnames=list(rownames,colnames,traynames,boxnames))

print(myEggBoxes)

