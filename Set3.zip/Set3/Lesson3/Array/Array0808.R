# Create an array to store 48 eggs

eggs<-array(1:48,dim = c(2,4,3,2))
print(eggs)

r1<-c("Row1","Row2")
c1<-c("C1","C2","C3","C4")
t1<-c("Tray1","Tray2","Tray3")
b1<-c("Box1","Box2")

eggs<-array(1:48,dim = c(2,4,3,2),
            dimnames = list(r1,c1,t1,b1))
print(eggs)

eggs[1,2,1,2]
eggs["Row2",,"Tray3","Box1"]
eggs["Row2",,"Tray3",]
eggs[,,"Tray2",]
eggs[,,"Tray2","Box1"]
eggs[,,,"Box2"]


# Appraisal data for one employee
appdata1<-matrix(c(1,3,3,4,2,2,3,3),ncol=4,
                 dimnames = list(
                   c("2016","2017"),
                   c("Q1","Q2","Q3","Q4")
                 ))

print(appdata1)

#Storing appraisal data for 3 employees

appDataFor3<-array(c(1,3,3,4,2,2,3,3,2,2,2,2,2,2,2,2,
                     1,4,1,4,1,4,1,4),
                   dim=c(2,4,3),
                   dimnames = list(
                     c("2016","2017"),
                     c("Q1","Q2","Q3","Q4"),
                     c("Ram","Tarun","Vinu")
                   )
                   )

print(appDataFor3)

#Print Q1 appraisal data

appDataFor3[,"Q1",]

#Whoever gets rating 4 make it to 5
appDataFor3[appDataFor3==4]<-5

print(appDataFor3)





