

#desig is a vector
desig<-c("SE","SSE","AM","Mgr","SSE","SSE","AM","Mgr",
         "SE","SSE","SE","AM",
         "SSE","SSE","AM","SSE",
         "SSE","SSE","Mgr","Mgr",
         "SE","SSE","AM","AM")

print(desig)
# Categorical data - SE,SSE,AM,Mgr

# Step 1->Find Unique values- SE,SSE,AM,Mgr
# Step 2-> Sort the Unique values-AM,Mgr,SE,SSE
# Step 3 -> Create Levels -AM,Mgr,SE,SSE
# Step 4-> Assign number to every level, AM=1, Mgr=2,SE=3, SSE=4
# Step 5-> Store data based on numbers
# 3,4,1,2,4,4,1,2...

# Create a factor for desig
#fdesig is a factor
fdesig<-factor(desig)
print(fdesig)
str(fdesig)

fdesig[1]<-"SSE"
print(fdesig)

fdesig[4]<-"VP"
print(fdesig)

fdesig1<-factor(desig,levels=c("SE","SSE","AM","Mgr","VP","Director"))
print(fdesig1)
str(fdesig1)
fdesig1[4]<-"VP"
print(fdesig1)
str(fdesig1)

#Count the employees in each designation - tabulate- table
table(fdesig1)



feedData<-chickwts$feed
print(feedData)

feedfactor<-factor(feedData)
print(feedfactor)
table(feedfactor)


table(factor(CO2$Plant))











