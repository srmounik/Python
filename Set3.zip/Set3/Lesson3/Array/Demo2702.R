# Array
eggs<-1:48

eggShelf<-array(
  eggs,
  dim=c(2,4,3,2),
  dimnames=list(
    c("Row1","Row2"),
    c("Col1","Col2","Col3","Col4"),
    c("Tray1","Tray2","Tray3"),
    c("Box1","Box2")
  )
)

print(eggShelf)

eggShelf[1,4,2,1]
eggShelf[2,,2,1]
eggShelf[,,3,1]
eggShelf[,,,2]



# Appraisal Data for 4 employees - 2017 and 2018
a1<-c(1,2,3,4,1,2,3,4)
a2<-c(2,1,2,1,2,1,2,1)
a3<-c(1,2,3,1,2,3,1,2)
a4<-c(3,2,3,2,3,4,3,4)

# 3 Dimensional Array
appraisalData<-array(c(a1,a2,a3,a4),
                    dim=c(2,4,4),
                    dimnames = list(
                          c("2016","2017"),
                          c("Q1","Q2","Q3","Q4"),
                          c("Sam","Tom","Smith","Allen")
                       ))
print(appraisalData)

# Allen's 2017, Q3 rating

appraisalData[2,3,4]
appraisalData["2017","Q3","Allen"]

which(appraisalData>2,arr.ind = TRUE)

# who all have got rating 4
which(apprisalData==4,arr.ind = TRUE)

rainfall<-array(1:16,dim=c(1,4,2,2),
                dimnames = list(
                          c("Rainfall"),
                          month.abb[1:4],
                          c("State1","State2"),
                          c("Country1","Country2")
                ))
print(rainfall)

rainfall[1,2,2,]
rainfall[,2,2,]



















