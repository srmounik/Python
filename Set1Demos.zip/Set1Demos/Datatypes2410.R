# Data Type
# Decimal 
salary<-78778
typeof(salary)
class(salary)

is.integer(salary)

interest<-677.45
typeof(interest)
class(interest)

#Integer
empid<-345L
typeof(empid)
class(empid)

#Complex - Real part and Imaginary part
result<-67+4i
# Real part=67, imaginary=4
print(result)
typeof(result)
class(result)
Re(result)
Im(result)

distance=8i

c1<-4+7i
c2<-19+3i

print(c1+c2)

# Character Variables
message<-"Arun's pen is amazing"
print(message,quote=FALSE)

q1<-'GandhiJi said, "Do or Die", Lets follow...'
print(q1,quote=FALSE)

name<-"Allen"
desig<-"SSE"
salary<- 67677
loc<-"Pune"

# Paste- sep="|"

print(paste(name,desig,salary,loc),quote=FALSE)

print(paste(name,desig,salary,loc,sep = ","),quote=FALSE)

print(paste(name,desig,salary,loc,sep = "--"),quote=FALSE)

print(paste("Name :",name," Salary :",salary," Desig:",desig," Location:",loc),quote = FALSE)

print(paste("Name :",name," Salary :",salary," Desig:",desig," Location:",loc))


#Logical

isAvailable<-TRUE
inStock<-FALSE
isValid<-F

# Conversion of Variables in R - as.xxxx()

# Numeric to other types
salary<-8989.50
typeof(salary)
sal<-as.integer(salary)
imginarySal<-as.complex(salary)
mySal<-as.character(salary)
goodSal<-as.logical(salary)


# Integer to other types
salary<-5643L
typeof(salary)
typeof(as.numeric(salary))
as.complex(salary)
as.character(salary)
as.logical(salary)

score<--56
as.logical(score)

points<-0
as.logical(points)


# Complex to other types
salary<-5.55+8i
typeof(salary)
res<-as.numeric(salary)
as.integer(salary)
as.character(salary)
as.logical(salary)

c1<-80+0i
c2<-0+5i
c3<-0+0i
as.logical(c1)
as.logical(c2)
as.logical(c3)


# Logical to other types
isValid<-FALSE # FALSE-0, TRUE-1
as.numeric(isValid)
as.integer(isValid)
as.complex(isValid)
as.character(isValid)

#Character to others
msg<-"Welcome"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

msg<-"67676.65"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)


msg<-"1"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

msg<-"TRUE"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)

msg<-"F"
as.numeric(msg)
as.integer(msg)
as.complex(msg)
as.logical(msg)



