#Numeric Constants - Double, Integer -L, Complex - i
typeof(5)
typeof(5.0)
typeof(5L)
typeof(43789L)
typeof(56.34)
typeof(856i)

#Character Constants - "", ''
typeof("Hello")
typeof('Welcome')
typeof("56788")
typeof("TRUE")
typeof("This is Hema's pen")
typeof('Gandhiji said "Do or Die"')

#Logical Constant - TRUE, FALSE, T, F
typeof(T)
typeof(FALSE)

n1=10.45
n2=2.5
print(n1+n2)
print(n1-n2)
print(n1*n2)
print(n1/n2)
print(n1%%n2) #Reminder
print(n1%/%n2) #Quotient


accountBalance=78889
withdraw=20000
print(accountBalance>withdraw)

# To read data from user

name=readline(prompt="Enter ur name :")
age=readline(prompt="Enter ur age :")
typeof(age)
print(name)
print(age)
age=as.integer(age)
typeof(age)



accountBalance=78889
withdraw=readline(prompt="Enter the anount to withdraw :")
withdraw=as.integer(withdraw)
print(accountBalance>withdraw)

print(TRUE&FALSE)
print(TRUE&&FALSE)
print(TRUE|FALSE)
print(TRUE||FALSE)

# Assignment Operators in R - =, <-, -> , <<-, ->>

# = Should be used to create Key value pairs
scores<-c("Hema"=90,"Anu"=50,"Vinu"=70)
print(scores)

#Incorrect
scores1<-c("Hema"<-90,"Anu"<-50,"Vinu"<-70)
print(scores1)

# <- To create variables
x<-5
company<-"Capgemini"

# -> To create variable
6->y 
"Allen"->username

# <<-, ->> , see the definition in Functions

print(9/4) # Quotient - 2 and reminder -1, decimal - 2.25
print(9%/%4)
print(9%%4)





